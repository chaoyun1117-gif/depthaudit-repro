# Full reproduction bundle — gut archaea detection limits

This bundle reproduces the analysis and figures for:

> Sequencing-depth-dependent detection limits of gut methanogenic archaea
> and detection-driven distortion of microbiome–disease associations

It is a **mixed R + Python + shell** reproduction bundle, not a CRAN-only R
package. R is used for `curatedMetagenomicData` export and the R bridge;
Python is used for the depth model, two-part model and figure generation.

## Quick start

```bash
cd R_repro_bundle_2026-11-21
bash run_all.sh
```

The script:

1. fetches `sampleMetadata.csv` and `EH_archaea_long.rds` from
   `curatedMetagenomicData`;
2. converts the long table to `EH_archaea_merged.csv`;
3. runs the DepthAudit depth/two-part models;
4. runs the original statistical and figure scripts.

All commands run with:

```bash
ulimit -v <75% of MemTotal>
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
```

## What is included

```text
R_repro_bundle_2026-11-21/
├── README.md
├── run_all.sh
├── data/
│   ├── EH_archaea_long.rds
│   ├── EH_archaea_merged.csv
│   ├── sampleMetadata.csv
│   └── dedup_analysis.csv
├── scripts/
│   ├── fetch_cmd.R
│   └── export_cmd.R
├── depthaudit/                 # Python CLI + models + tests
├── code/                       # original Additional_file_3 package, unpacked
│   ├── 00_download/manifests/  # raw-read download manifests
│   ├── 03_raw_read/
│   ├── 04_cmd/
│   ├── 05_stats/
│   └── 06_figures/
├── figures/                    # current main/supplementary figures
├── figures_tiff/               # TIFF versions
├── environment/
│   ├── sessionInfo.txt
│   └── pip-freeze.txt
└── checksums.sha256
```

## Important data caveat

Raw FASTQ files are **not** bundled. The original package includes download
manifests for the 10 raw-read cohorts; downloading all FASTQ requires roughly
100 GB. The statistical and figure steps can be run from the included derived
tables without downloading FASTQ.

The current `curatedMetagenomicData` snapshot yields:

- 21,570 rows in `EH_archaea_long.rds`;
- 21,393 unique samples after de-duplication;
- 83 studies;
- detection rate 26.12%.

The manuscript archive used 21,400 samples / 83 studies. The 7-sample
difference is due to the cMD snapshot; pin the 2021 snapshots or filter to the
archived `dedup_analysis.csv` sample list to reproduce the exact manuscript
numbers.

## R requirements

- R 4.3.3
- Bioconductor 3.18
- `curatedMetagenomicData` 3.10.0
- `ExperimentHub`
- `treeio`, `TreeSummarizedExperiment`, `mia`

If `curatedMetagenomicData` is missing:

```bash
Rscript -e 'BiocManager::install("curatedMetagenomicData", ask=FALSE, update=FALSE)'
```

## Python requirements

```bash
python3 -m pip install -r depthaudit/requirements.txt
```

or install the local package:

```bash
python3 -m pip install -e depthaudit
```

## Direct verification

```bash
cd depthaudit
PYTHONPATH=. python3 -m depthaudit audit \
  --input ../data/EH_archaea_merged.csv \
  --out /tmp/depthaudit_verify \
  --self-check
```

`--self-check` is intentionally strict and will fail on the current cMD snapshot
because it expects the archived 21,400-sample numbers. Run without
`--self-check` to audit the current snapshot.

## Figure generation

The original figure scripts are in `code/06_figures/`:

```bash
cd code
cp ../data/dedup_analysis.csv .
cp ../data/EH_archaea_merged.csv .
cp ../data/sampleMetadata.csv .
cp outputs/*.json .
python3 04_cmd/analysis_final.py
python3 05_stats/prep_v3.py
python3 05_stats/adjusted_estimates.py
python3 06_figures/make_composites_v4.py
python3 06_figures/build_supp_xlsx.py
```

Generated figures are written to `code/figures/`.

## Resource safety

The `run_all.sh` wrapper derives the memory cap from `/proc/meminfo` at 75%
and forces single-threaded BLAS/OMP. The full R export is streamed study by
study, so it does not hold the complete 22k × 300 matrix in memory.
