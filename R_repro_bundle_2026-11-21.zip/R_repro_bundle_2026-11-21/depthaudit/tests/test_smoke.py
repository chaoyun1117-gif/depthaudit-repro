import unittest

import pandas as pd

from depthaudit.io import detection_summary, normalize
from depthaudit.models import audit


class TestDepthAuditSmoke(unittest.TestCase):
    def test_normalize_and_summary(self):
        raw = pd.DataFrame(
            {
                "sample": ["s1", "s2", "s2", "s3"],
                "study": ["A", "A", "A", "B"],
                "disease": ["CRC", "healthy", "healthy", "healthy"],
                "archaea_rel": [0.01, 0.0, 0.0, 0.02],
                "number_reads": [1_000_000, 500_000, 500_000, 2_000_000],
            }
        )
        df = normalize(raw)
        self.assertEqual(len(df), 3)  # duplicate s2 dropped
        self.assertEqual(detection_summary(df)["n_samples"], 3)
        self.assertEqual(detection_summary(df)["n_studies"], 2)
        self.assertAlmostEqual(detection_summary(df)["detection_pct"], 66.67, places=2)

    def test_audit_runs(self):
        raw = pd.DataFrame(
            {
                "sample": [f"s{i}" for i in range(12)],
                "study": ["A"] * 6 + ["B"] * 6,
                "disease": ["CRC"] * 3 + ["healthy"] * 3 + ["CRC"] * 3 + ["healthy"] * 3,
                "archaea_rel": [0.02, 0.01, 0.0, 0.0, 0.0, 0.0, 0.03, 0.0, 0.02, 0.0, 0.0, 0.0],
                "number_reads": [1e6, 8e5, 5e5, 4e5, 3e5, 2e5] * 2,
            }
        )
        result = audit(normalize(raw), ["CRC"])
        self.assertIn("summary", result)
        self.assertIn("depth", result)
        self.assertIn("CRC", result["two_part"])


if __name__ == "__main__":
    unittest.main()
