#!/usr/bin/env Rscript
# Fetch the curatedMetagenomicData inputs used by DepthAudit.
#
# Requirements:
#   BiocManager::install("curatedMetagenomicData")
#
# Outputs:
#   sampleMetadata.csv
#   EH_archaea_long.rds
#
# The exact cMD snapshot changes over time. Record the date printed below in
# your lab notebook or manuscript methods.

if (!requireNamespace("curatedMetagenomicData", quietly = TRUE)) {
  stop(
    "curatedMetagenomicData is not installed. Run:\n",
    '  Rscript -e \'BiocManager::install("curatedMetagenomicData", ask=FALSE, update=FALSE)\''
  )
}

suppressPackageStartupMessages({
  library(curatedMetagenomicData)
  library(ExperimentHub)
})

cat("curatedMetagenomicData run date:", as.character(Sys.Date()), "\n")

sm <- curatedMetagenomicData::sampleMetadata
write.csv(sm, "sampleMetadata.csv", row.names = FALSE)

studies <- unique(sm$study_name)
message(
  "Fetching relative_abundance for ", length(studies),
  " studies one at a time; this keeps only one study matrix in memory."
)

chunks <- vector("list", length(studies))
for (i in seq_along(studies)) {
  study <- studies[[i]]
  message(sprintf("[%d/%d] %s", i, length(studies), study))
  sub <- subset(sm, study_name == study)

  resource <- tryCatch(
    suppressMessages(returnSamples(
      sub,
      "relative_abundance",
      counts = FALSE,
      rownames = "long"
    )),
    error = function(e) {
      warning("Skipping ", study, ": ", conditionMessage(e), call. = FALSE)
      NULL
    }
  )
  if (is.null(resource)) {
    next
  }

  mat <- assay(resource)
  rn <- rownames(resource)
  archaea_rows <- grepl("^k__Archaea", rn)
  if (!any(archaea_rows)) {
    warning("No k__Archaea rows for ", study, call. = FALSE)
    rm(resource, mat)
    gc()
    next
  }

  archaea_rel <- colSums(mat[archaea_rows, , drop = FALSE], na.rm = TRUE)
  chunks[[i]] <- data.frame(
    sample = colnames(resource),
    taxon = "k__Archaea",
    relative_abundance = as.numeric(archaea_rel),
    stringsAsFactors = FALSE
  )

  rm(resource, mat, rn, archaea_rows, archaea_rel)
  gc()
}

chunks <- Filter(Negate(is.null), chunks)
if (length(chunks) == 0) {
  stop("No studies produced a k__Archaea abundance table.")
}

expr <- do.call(rbind, chunks)
saveRDS(expr, "EH_archaea_long.rds")
message(
  "Wrote EH_archaea_long.rds with ", nrow(expr),
  " samples from ", length(chunks), " studies."
)
cat("Wrote sampleMetadata.csv and EH_archaea_long.rds\n")
