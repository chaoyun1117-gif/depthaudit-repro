#!/usr/bin/env Rscript
# Export curatedMetagenomicData long-format archaea abundances to the CSV
# expected by DepthAudit / the original analysis scripts.
#
# Usage:
#   Rscript scripts/export_cmd.R [EH_archaea_merged.csv] [sampleMetadata.csv]
#
# Input:
#   EH_archaea_long.rds  produced by 00_download/fetch_cmd.R
# Output:
#   EH_archaea_merged.csv with sample, study, disease, archaea_rel,
#   number_reads, number_bases, country, sequencing_platform,
#   DNA_extraction_kit

args <- commandArgs(trailingOnly = TRUE)
out_csv <- if (length(args) >= 1) args[1] else "EH_archaea_merged.csv"
meta_csv <- if (length(args) >= 2) args[2] else "sampleMetadata.csv"

if (!file.exists("EH_archaea_long.rds")) {
  stop("EH_archaea_long.rds not found. Run 00_download/fetch_cmd.R first.")
}

expr <- readRDS("EH_archaea_long.rds")

# curatedMetagenomicData may return a DataFrame or a list of data frames.
if (is.list(expr) && !is.data.frame(expr)) {
  expr <- as.data.frame(expr[[1]])
}
expr <- as.data.frame(expr)

message("Long table columns: ", paste(names(expr), collapse = ", "))
message("Long table rows: ", nrow(expr))

find_col <- function(candidates) {
  hit <- candidates[candidates %in% names(expr)]
  if (length(hit) == 0) NA_character_ else hit[[1]]
}

sample_col <- find_col(c("sample", "sample_id", "Sample"))
taxon_col <- find_col(c("taxon", "taxon_name", "feature", "rownames"))
value_col <- find_col(c("relative_abundance", "value", "abundance", "counts"))

if (any(is.na(c(sample_col, taxon_col, value_col)))) {
  stop(
    "Could not identify sample/taxon/value columns. Found: ",
    paste(names(expr), collapse = ", ")
  )
}

long <- data.frame(
  sample = as.character(expr[[sample_col]]),
  taxon = as.character(expr[[taxon_col]]),
  value = as.numeric(expr[[value_col]]),
  stringsAsFactors = FALSE
)
long <- long[!is.na(long$sample) & !is.na(long$value), ]

# Prefer the domain-level row; fall back to any non-genus archaeal row.
arc <- long[long$taxon == "k__Archaea", , drop = FALSE]
if (nrow(arc) == 0) {
  arc <- long[
    grepl("archaea", long$taxon, ignore.case = TRUE) &
      !grepl("^g__", long$taxon),
    ,
    drop = FALSE
  ]
}
if (nrow(arc) == 0) {
  stop("No k__Archaea (or non-genus archaeal) rows found in the long table.")
}

arc <- aggregate(value ~ sample, data = arc, FUN = sum, na.rm = TRUE)
names(arc)[names(arc) == "value"] <- "archaea_rel"

if (requireNamespace("curatedMetagenomicData", quietly = TRUE)) {
  sm <- curatedMetagenomicData::sampleMetadata
  write.csv(sm, meta_csv, row.names = FALSE)
} else if (file.exists(meta_csv)) {
  sm <- read.csv(meta_csv, check.names = FALSE, stringsAsFactors = FALSE)
  message("curatedMetagenomicData not installed; using existing ", meta_csv)
} else {
  stop(
    "curatedMetagenomicData not installed and ", meta_csv,
    " not found. Install the package or provide sampleMetadata.csv."
  )
}

meta_cols <- intersect(
  c(
    "sample_id", "study_name", "study", "disease", "number_reads",
    "number_bases", "country", "sequencing_platform", "DNA_extraction_kit"
  ),
  names(sm)
)
meta <- sm[, meta_cols, drop = FALSE]
if ("sample_id" %in% names(meta)) {
  names(meta)[names(meta) == "sample_id"] <- "sample"
}
if (!"study" %in% names(meta) && "study_name" %in% names(meta)) {
  meta$study <- meta$study_name
}
if (!"study" %in% names(meta)) {
  meta$study <- NA_character_
}
if (!"disease" %in% names(meta)) {
  meta$disease <- NA_character_
}

merged <- merge(arc, meta, by = "sample", all.x = TRUE)
write.csv(merged, out_csv, row.names = FALSE)

message("Wrote ", out_csv, " with ", nrow(merged), " samples.")
if (requireNamespace("curatedMetagenomicData", quietly = TRUE)) {
  message("Wrote ", meta_csv, " with ", nrow(sm), " metadata rows.")
}
