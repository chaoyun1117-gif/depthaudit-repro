# DepthAudit prototype status

Date: 2026-11-13

## Implemented

- `depthaudit` Python package with CLI:
  - `depthaudit audit --input ... --taxon archaea_rel --disease CRC --disease IBD --out ...`
- Input normalization/validation (`io.py`).
- Depth model: `det ~ log10(reads) + study fixed effects`.
- Two-part detection: disease effect on detection.
- Hedges' g pooling: full scale and among-detected.
- JSON + Markdown report writer.
- `scripts/export_cmd.R` bridge from `EH_archaea_long.rds` to
  `EH_archaea_merged.csv`.
- End-to-end bridge test: 21,400-row synthetic long table -> `out.csv`;
  `archaea_rel` max absolute difference vs source = **0.0**.
- `--self-check` flag asserts the manuscript's headline numbers.
- Demo data: `examples/demo_counts.tsv` (276 samples, 6 studies).
- Unit tests: `tests/test_smoke.py`.
- `Dockerfile`, `LICENSE`, `requirements.txt`, `pyproject.toml`.

## Verification on full `newreview/dedup_analysis.csv`

Command:

```bash
cd depthaudit
python3 -m depthaudit audit --input ../newreview/dedup_analysis.csv \
  --out /tmp/depthaudit_full2 --quiet
```

Results matched the manuscript:

- Samples: **21,400**
- Studies: **83**
- Detected: **5,590**
- Detection: **26.12%**
- Depth OR: **2.963** (2.493–3.521), p **5.96e-35**, pseudo-R² **0.194**
- CRC two-part detection OR: **1.834** (1.388–2.424)
- IBD two-part detection OR: **0.305** (0.228–0.409)
- CRC full-scale g: **0.312** (0.136–0.488)
- IBD full-scale g: **−0.396** (−0.672 to −0.120)

## Tests

```bash
cd depthaudit
python3 -m unittest discover -s tests -v
```

Result: **2 tests, OK**.

Self-check:

```bash
python3 -m depthaudit audit --input ../newreview/dedup_analysis.csv \
  --out /tmp/depthaudit_selfcheck --quiet --self-check
# self-check: OK
```

## Not yet done

- Raw-read shell pipeline (FASTQ → bowtie2/samtools) is not wrapped into the CLI.
- Figure generation remains in the original `Additional_file_3` package.
- No GitHub/Zenodo DOI yet.

## Next

1. Test `export_cmd.R` with a real `curatedMetagenomicData` `.rds`.
2. Wrap the raw-read shell pipeline or link to it from the README.
3. Publish GitHub repo + Zenodo DOI (requires user approval).
4. Add `Data and Code Availability` text to the iMeta manuscript.
