# Additional_file_3.zip → DepthAudit 改造审计

审计日期：2026-11-13  
源包：`newreview/Microbiome_upload/03_Additional_Files/Additional_file_3.zip`  
大小：117 KB，51 个文件  
完整性：`unzip -t` 通过；`checksums.sha256` 全部 OK。  
结论：**这是一个“复现包”，不是可复用工具。** 代码能支撑论文复现，但不能直接作为 `DepthAudit` 发布；需要补输入桥接、CLI、依赖、示例、测试和文档。

---

## 1. 包里有什么

| 目录/文件 | 作用 | 状态 |
|---|---|---|
| `00_download/` | 10 个队列的 ENA/SRA manifest + 下载脚本 | 可用，但需网络和约 100 GB 磁盘 |
| `01_reference/` | 古菌/16S bowtie2 索引构建 | 可用，依赖 `efetch`、`bowtie2` |
| `02_qc/` | QC 说明（未做 adapter trimming） | 仅说明 |
| `03_raw_read/` | downsampling、MAPQ、16S 定量 | 可用，依赖 `bowtie2`/`samtools` |
| `04_cmd/` | `prepare_data.py`、`analysis_final.py` | 核心统计，但路径/输入写死 |
| `05_stats/` | `prep_v3.py`、`adjusted_estimates.py` | 核心统计，但依赖根目录文件 |
| `06_figures/` | 主图、补充表生成 | 依赖多个中间文件 |
| `outputs/` | JSON 结果副本 | 只有 `outputs/` 副本，figure 脚本却读根目录 |
| `16s_full_results.tsv` | 外部 16S 队列结果 | 1,068 行，全部 OK |
| `cohort_overlap.csv` | 队列与 cMD 重叠关系 | 已列出外部验证候选 |
| `input_manifest.tsv` | 输入文件清单 | 明确写出哪些没带 |
| `README.md` | 复现步骤 | 部分描述与包内容不一致 |

---

## 2. 关键缺口（按严重程度）

### P0：包内没有核心输入

`input_manifest.tsv` 明确写着：

- `EH_archaea_merged.csv`：`no (large)`
- `sampleMetadata.csv`：`no (large)`
- FASTQ：`no (large)`

包里也没有 `inputs/` 目录，尽管 README 说“small derived tables are also provided in `inputs/`”。  
所以现在这个包 **不能从零跑通统计线**，只能复现已经有中间文件的部分。

### P0：R 导出与 Python 输入不衔接

`00_download/fetch_cmd.R` 最后写的是：

```r
saveRDS(expr, "EH_archaea_long.rds")
```

但 `04_cmd/prepare_data.py` 和 `04_cmd/analysis_final.py` 读的是：

```python
pd.read_csv("EH_archaea_merged.csv")
```

**缺少一个 `EH_archaea_long.rds` → `EH_archaea_merged.csv` 的桥接脚本。**  
而且 `prepare_data.py` 需要 `sample`、`study`、`disease`、`archaea_rel` 等列，`fetch_cmd.R` 并没有生成这些列。

### P1：依赖没有声明

`requirements.txt` 只有注释，没有 Python 包。实际用到：

- pandas
- numpy
- statsmodels
- scipy
- matplotlib
- openpyxl

R 侧还需要：

- `curatedMetagenomicData`
- `ExperimentHub`

外部工具：`bowtie2`、`samtools`、`wget`/`curl`、`efetch`。

### P1：没有 CLI，路径靠 cwd

- `analysis_final.py` 没有 `argparse`，默认从当前目录读 `EH_archaea_merged.csv`；
- `prep_v3.py` 默认读 `dedup_analysis.csv`；
- `make_composites_v4.py` 把 `OUT="figures/"` 写死；
- `05_stats/adjusted_estimates.py` 虽然 `os.chdir` 到包根目录，但其他脚本没有统一。

这意味着用户必须“在正确目录下按正确顺序运行”，不适合作为工具发布。

### P1：没有示例数据/测试

没有：

- `examples/` 小数据；
- `tests/`；
- 期望输出断言（21,400、26.12%、OR 2.963）；
- license；
- `CITATION.cff`；
- Docker/Singularity。

### P2：输出路径不一致

`outputs/` 里有：

- `outputs/final_numbers.json`
- `outputs/pool_v3.json`
- `outputs/adjusted_estimates.json`

但 `06_figures/make_composites_v4.py` 读的是根目录：

```python
P=json.load(open("pool_v3.json"))
FN=json.load(open("final_numbers.json"))
```

所以直接跑 figure 脚本会找不到文件，除非先运行统计脚本在根目录生成，或手动复制。

---

## 3. 外部队列：其实已经有可用数据

`cohort_overlap.csv` 已经把外部验证候选列出来了：

| Accession | 在 cMD 中 | 角色 |
|---|---|---|
| `PRJEB53891` | No | External independent validation, CRC Asia |
| `PRJNA763023` | No | External independent validation, CRC China |
| `PRJDB16834` | No | External independent validation, Adenoma Japan |
| `PRJDB11845` | No | External independent validation, CRC Japan |

`16s_full_results.tsv` 已经有 1,068 个样本：

- `PRJEB53891`：30 个
- `PRJNA763023`：1,038 个
- 全部 `status=OK`

所以 **不需要为了“外部队列”重新下载 100 GB 数据**；现有 16S 外部数据已经可以支撑“external 16S validation”。  
但注意：这是 **16S rRNA gene** 外部验证，不是 shotgun 外部队列；写作时要明确区分，不能把它说成 independent shotgun cohort。

`PRJDB16834`、`PRJDB11845` 在 `cohort_overlap.csv` 里也标为外部，但不在 `16s_full_results.tsv` 中；它们目前在正文 Table 11 里，需要确认原始结果文件是否齐全。

---

## 4. 改造成 DepthAudit 需要补什么

### 最小可用版本（3–5 天）

```text
depthaudit/
├── pyproject.toml
├── requirements.txt
├── README.md
├── LICENSE
├── CITATION.cff
├── Dockerfile
├── depthaudit/
│   ├── __init__.py
│   ├── __main__.py
│   ├── cli.py
│   ├── io.py
│   ├── models.py
│   └── report.py
├── scripts/
│   └── export_cmd.R
├── examples/
│   ├── demo_counts.tsv
│   └── demo_metadata.tsv
└── tests/
    └── test_smoke.py
```

### 每个文件的作用

| 文件 | 作用 |
|---|---|
| `scripts/export_cmd.R` | 把 `EH_archaea_long.rds` 转成 `EH_archaea_merged.csv`，补 `sample/study/disease/archaea_rel` |
| `depthaudit/io.py` | 读 count/metadata，校验列、去重、统一 `st` |
| `depthaudit/models.py` | 检测率、logistic 深度模型、two-part、Hedges' g、随机效应 |
| `depthaudit/report.py` | 输出 JSON/CSV + HTML 摘要 |
| `depthaudit/cli.py` | `depthaudit audit --input ... --metadata ... --taxon ... --out ...` |
| `examples/` | 200–500 行脱敏/子集数据，保证无原始大文件也能跑 |
| `tests/test_smoke.py` | 断言 21,400、26.12%、OR≈2.963（用完整输入时） |
| `Dockerfile` | 固定 Python/R/外部工具版本 |

### CLI 目标接口

```bash
depthaudit audit \
  --counts dedup_analysis.csv \
  --metadata sampleMetadata.csv \
  --taxon archaea_rel \
  --out results/
```

输出：

- `results/detection_summary.csv`
- `results/depth_model.json`
- `results/two_part.json`
- `results/report.html`

---

## 5. 建议的改造顺序

1. **先补 `export_cmd.R`**：让 R 导出和 Python 输入真正接上；
2. **把 `analysis_final.py` 拆成函数**：`fit_depth_model()`、`two_part()`、`pool_effects()`；
3. **加 CLI 和输入校验**：不再依赖 cwd；
4. **加 `examples/` + `tests/`**：先用 `newreview/dedup_analysis.csv` 的 500 行子集；
5. **加 Docker**：固定 `pandas/statsmodels` 版本；
6. **发布 GitHub + Zenodo**：拿 DOI，写进 iMeta 的 Data and Code Availability。

---

## 6. 最终判断

- **能改**：核心统计代码齐全，结果数字可复现，改造成本主要是工程包装，不是重做分析。
- **不能直接发**：当前 zip 是 supplementary code，不是 installable tool；缺输入桥接、依赖、CLI、示例、测试。
- **外部队列不用重新下载**：`PRJEB53891` + `PRJNA763023` 已经是外部 16S 验证；写作时把它明确为 external 16S validation 即可。
- **优先级**：先做 `DepthAudit` 最小 CLI + 外部 16S 验证重述；true shotgun 外部队列作为可选加强项。
