# Demo data

`demo_counts.tsv` is a 480-row subset of the de-duplicated public
curatedMetagenomicData table used in the manuscript. It contains CRC, IBD and
healthy samples only, with `sample`, `study`, `disease`, `archaea_rel`, and
`number_reads`.

Run:

```bash
depthaudit audit --input depthaudit/examples/demo_counts.tsv --out /tmp/depthaudit_demo
```
