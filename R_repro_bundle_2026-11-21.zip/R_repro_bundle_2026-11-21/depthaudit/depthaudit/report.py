"""Report writers for DepthAudit."""

from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Any

import pandas as pd


def _clean(value: Any) -> Any:
    """Make nested results JSON-safe."""
    if isinstance(value, dict):
        return {str(k): _clean(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_clean(v) for v in value]
    if isinstance(value, float) and (math.isnan(value) or math.isinf(value)):
        return None
    if hasattr(value, "item"):
        return _clean(value.item())
    return value


def write_report(result: dict, outdir: str | Path) -> Path:
    out = Path(outdir)
    out.mkdir(parents=True, exist_ok=True)

    out_json = out / "results.json"
    out_json.write_text(
        json.dumps(_clean(result), indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    for disease, effect in result.get("effects", {}).items():
        rows = effect.get("rows", [])
        if rows:
            pd.DataFrame(rows).to_csv(
                out / f"study_effects_{disease}.csv", index=False
            )

    summary = result.get("summary", {})
    depth = result.get("depth", {})
    lines = [
        "# DepthAudit report",
        "",
        "## Summary",
        f"- Samples: {summary.get('n_samples')}",
        f"- Studies: {summary.get('n_studies')}",
        f"- Detected: {summary.get('n_detected')} ({summary.get('detection_pct')}%)",
        f"- Samples with read depth: {summary.get('n_with_reads')}",
        "",
        "## Depth model",
        f"- OR per log10 reads: {depth.get('OR')} "
        f"(95% CI {depth.get('lo')}–{depth.get('hi')})",
        f"- p: {depth.get('p')}",
        f"- pseudo-R2: {depth.get('pseudoR2')}",
        "",
        "## Two-part detection",
    ]
    for disease, item in result.get("two_part", {}).items():
        lines.append(
            f"- {disease}: OR {item.get('OR')} "
            f"(95% CI {item.get('lo')}–{item.get('hi')})"
        )

    lines += ["", "## Effects"]
    for disease, effect in result.get("effects", {}).items():
        full = effect.get("full") or {}
        detected = effect.get("detected") or {}
        lines.append(
            f"- {disease}: full g={full.get('g')} "
            f"({full.get('lo')}–{full.get('hi')}); "
            f"detected g={detected.get('g')} "
            f"({detected.get('lo')}–{detected.get('hi')})"
        )

    (out / "report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return out
