"""DepthAudit: depth-aware detection audit for microbiome-disease associations."""

__version__ = "0.1.0"
