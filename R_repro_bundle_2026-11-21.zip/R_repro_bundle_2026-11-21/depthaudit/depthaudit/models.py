"""Core statistical models used by DepthAudit.

The functions deliberately mirror the published analysis:
- detection ~ log10(reads) + study fixed effects
- two-part decomposition: detection vs abundance conditional on detection
- Hedges' g random-effects pooling
"""

from __future__ import annotations

import math
import warnings
from typing import Iterable

import numpy as np
import pandas as pd
import statsmodels.formula.api as smf
from statsmodels.tools.sm_exceptions import ConvergenceWarning


def _exp(value: float) -> float:
    """Overflow-safe exponential for reporting ORs."""
    return float(np.exp(np.clip(value, -700, 700)))


def _fit_logit(formula: str, data: pd.DataFrame):
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", ConvergenceWarning)
        try:
            return smf.logit(formula, data=data).fit(disp=0, maxiter=500)
        except Exception:
            # Fall back to a model without study fixed effects if a study has
            # separation or a single outcome level.
            return smf.logit(
                formula.replace(" + C(st)", ""), data=data
            ).fit(disp=0, maxiter=500)


def fit_depth_model(df: pd.DataFrame) -> dict:
    """Fit the depth-detection logistic model and return OR/CI/pseudo-R2."""
    dd = df.dropna(subset=["lg"]).copy()
    if dd.empty:
        return {}

    formula = "det ~ lg + C(st)" if dd["st"].nunique() > 1 else "det ~ lg"
    fit = _fit_logit(formula, dd)

    beta = float(fit.params["lg"])
    se = float(fit.bse["lg"])
    return {
        "formula": formula,
        "n": int(len(dd)),
        "n_studies": int(dd["st"].nunique()),
        "coef": round(beta, 4),
        "se": round(se, 4),
        "OR": round(_exp(beta), 3),
        "lo": round(_exp(beta - 1.96 * se), 3),
        "hi": round(_exp(beta + 1.96 * se), 3),
        "p": float(fit.pvalues["lg"]),
        "pseudoR2": round(float(fit.prsquared), 3),
    }


def _hedges_g(case: np.ndarray, control: np.ndarray) -> tuple[float, float]:
    n1, n2 = len(case), len(control)
    if n1 < 3 or n2 < 3:
        return math.nan, math.nan
    s1, s2 = np.nanstd(case, ddof=1), np.nanstd(control, ddof=1)
    sp = math.sqrt(((n1 - 1) * s1**2 + (n2 - 1) * s2**2) / (n1 + n2 - 2))
    if not math.isfinite(sp) or sp == 0:
        return math.nan, math.nan
    g = (np.nanmean(case) - np.nanmean(control)) / sp
    g *= 1 - 3 / (4 * (n1 + n2) - 9)
    se = math.sqrt((n1 + n2) / (n1 * n2) + g**2 / (2 * (n1 + n2)))
    return float(g), float(se)


def _pool(gs: Iterable[float], ses: Iterable[float]) -> dict | None:
    gs = np.asarray(list(gs), dtype=float)
    ses = np.asarray(list(ses), dtype=float)
    ok = np.isfinite(gs) & np.isfinite(ses) & (ses > 0)
    gs, ses = gs[ok], ses[ok]
    if len(gs) == 0:
        return None

    variances = ses**2
    w = 1 / variances
    mu = float((w * gs).sum() / w.sum())
    q = float((w * (gs - mu) ** 2).sum())
    c = float(w.sum() - (w**2).sum() / w.sum())
    tau2 = max(0.0, (q - (len(gs) - 1)) / c) if c > 0 else 0.0
    wr = 1 / (variances + tau2)
    mu = float((wr * gs).sum() / wr.sum())
    se = float(np.sqrt(1 / wr.sum()))
    i2 = max(0.0, (q - (len(gs) - 1)) / q * 100) if q > 0 else 0.0

    return {
        "k": int(len(gs)),
        "g": round(mu, 3),
        "lo": round(mu - 1.96 * se, 3),
        "hi": round(mu + 1.96 * se, 3),
        "I2": round(i2, 1),
        "tau2": round(float(tau2), 4),
    }


def pool_effects(df: pd.DataFrame, disease: str) -> dict:
    """Pool full-scale and among-detected Hedges' g for one disease."""
    sub = df[df["disease"].isin([disease, "healthy"])].copy()
    rows: list[dict] = []
    g_all, se_all, g_pos, se_pos = [], [], [], []

    for study, group in sub.groupby("st"):
        case = group[group["disease"] == disease]
        control = group[group["disease"] == "healthy"]
        if len(case) < 5 or len(control) < 5:
            continue

        g1, s1 = _hedges_g(
            np.log10(case["y"].to_numpy() + 1e-6),
            np.log10(control["y"].to_numpy() + 1e-6),
        )
        case_pos = case[case["y"] > 0]
        control_pos = control[control["y"] > 0]
        if len(case_pos) >= 5 and len(control_pos) >= 5:
            g2, s2 = _hedges_g(
                np.log10(case_pos["y"].to_numpy()),
                np.log10(control_pos["y"].to_numpy()),
            )
        else:
            g2, s2 = math.nan, math.nan

        rows.append(
            {
                "study": study,
                "n_case": int(len(case)),
                "n_control": int(len(control)),
                "g_full": None if math.isnan(g1) else round(g1, 4),
                "g_detected": None if math.isnan(g2) else round(g2, 4),
            }
        )
        g_all.append(g1)
        se_all.append(s1)
        g_pos.append(g2)
        se_pos.append(s2)

    return {
        "disease": disease,
        "full": _pool(g_all, se_all),
        "detected": _pool(g_pos, se_pos),
        "rows": rows,
    }


def two_part_detection(df: pd.DataFrame, disease: str) -> dict:
    """Logistic disease effect on detection (the first part of two-part)."""
    sub = df[df["disease"].isin([disease, "healthy"])].dropna(subset=["lg"]).copy()
    if sub.empty:
        return {}
    sub["case"] = (sub["disease"] == disease).astype(int)
    formula = "det ~ case + C(st)" if sub["st"].nunique() > 1 else "det ~ case"
    fit = _fit_logit(formula, sub)
    beta = float(fit.params["case"])
    se = float(fit.bse["case"])
    return {
        "formula": formula,
        "n": int(len(sub)),
        "OR": round(_exp(beta), 3),
        "lo": round(_exp(beta - 1.96 * se), 3),
        "hi": round(_exp(beta + 1.96 * se), 3),
        "p": float(fit.pvalues["case"]),
    }


def audit(df: pd.DataFrame, diseases: Iterable[str] = ("CRC", "IBD")) -> dict:
    """Run the full detection audit."""
    result = {
        "summary": {
            "n_samples": int(len(df)),
            "n_studies": int(df["st"].nunique()),
            "n_detected": int(df["det"].sum()),
            "detection_pct": round(float(df["det"].mean() * 100), 2),
            "n_with_reads": int(df["lg"].notna().sum()),
        },
        "depth": fit_depth_model(df),
        "two_part": {},
        "effects": {},
    }
    for disease in diseases:
        result["two_part"][disease] = two_part_detection(df, disease)
        result["effects"][disease] = pool_effects(df, disease)
    return result
