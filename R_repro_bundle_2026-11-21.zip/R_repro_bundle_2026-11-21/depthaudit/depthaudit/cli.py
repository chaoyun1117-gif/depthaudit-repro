"""Command-line interface for DepthAudit."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .io import normalize, read_table
from .models import audit
from .report import write_report


def _self_check(result: dict) -> None:
    """Fail loudly if the manuscript's headline numbers drift."""
    expected = {
        "n_samples": 21400,
        "n_studies": 83,
        "detection_pct": 26.12,
        "depth_OR": 2.963,
        "CRC_two_part_OR": 1.834,
        "IBD_two_part_OR": 0.305,
        "CRC_g": 0.312,
        "IBD_g": -0.396,
    }
    got = {
        "n_samples": result["summary"].get("n_samples"),
        "n_studies": result["summary"].get("n_studies"),
        "detection_pct": result["summary"].get("detection_pct"),
        "depth_OR": result.get("depth", {}).get("OR"),
        "CRC_two_part_OR": result.get("two_part", {}).get("CRC", {}).get("OR"),
        "IBD_two_part_OR": result.get("two_part", {}).get("IBD", {}).get("OR"),
        "CRC_g": (result.get("effects", {}).get("CRC", {}).get("full") or {}).get("g"),
        "IBD_g": (result.get("effects", {}).get("IBD", {}).get("full") or {}).get("g"),
    }
    failures = []
    for key, value in expected.items():
        actual = got.get(key)
        if actual is None or abs(float(actual) - float(value)) > 0.011:
            failures.append(f"{key}: expected {value}, got {actual}")
    if failures:
        raise ValueError("self-check failed: " + "; ".join(failures))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="depthaudit",
        description="Audit sequencing-depth-dependent detection in microbiome data.",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    run = sub.add_parser("audit", help="Run detection and two-part models.")
    run.add_argument("--input", required=True, help="CSV/TSV sample-level table.")
    run.add_argument(
        "--taxon",
        default="archaea_rel",
        help="Taxon abundance column (default: archaea_rel).",
    )
    run.add_argument(
        "--reads",
        default="auto",
        help="Read-depth column (default: auto-detect number_reads/nr/reads).",
    )
    run.add_argument(
        "--disease",
        action="append",
        default=None,
        help="Disease label to compare with healthy; repeatable (default: CRC and IBD).",
    )
    run.add_argument(
        "--out",
        default="depthaudit_results",
        help="Output directory (default: depthaudit_results).",
    )
    run.add_argument(
        "--quiet",
        action="store_true",
        help="Only write files; do not print the JSON summary.",
    )
    run.add_argument(
        "--self-check",
        action="store_true",
        help="Assert the manuscript's headline numbers (full dataset only).",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command != "audit":
        parser.error("Unknown command")

    try:
        raw = read_table(args.input)
        df = normalize(raw, taxon=args.taxon, reads=args.reads)
        diseases = args.disease or ["CRC", "IBD"]
        result = audit(df, diseases)
        if args.self_check:
            _self_check(result)
        out = write_report(result, args.out)
    except Exception as exc:
        print(f"depthaudit: error: {exc}", file=sys.stderr)
        return 1

    if not args.quiet:
        print(json.dumps(result, indent=2, ensure_ascii=False, default=str))
    if args.self_check:
        print("self-check: OK", file=sys.stderr)
    print(f"Wrote report to {Path(out).resolve()}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
