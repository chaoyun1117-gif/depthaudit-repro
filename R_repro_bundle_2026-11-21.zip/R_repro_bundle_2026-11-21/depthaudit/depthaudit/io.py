"""Input normalization and validation for DepthAudit."""

from __future__ import annotations

from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd

READ_COLUMNS = ("number_reads", "nr", "reads", "total_reads", "n_reads")
REQUIRED_COLUMNS = ("sample", "study", "disease")


def read_table(path: str | Path) -> pd.DataFrame:
    """Read a CSV or TSV table without changing the source file."""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Input table not found: {p}")
    sep = "\t" if p.suffix.lower() in {".tsv", ".tab"} else ","
    return pd.read_csv(p, sep=sep, low_memory=False)


def _first_present(columns: Iterable[str], candidates: Iterable[str]) -> str | None:
    columns = set(columns)
    for c in candidates:
        if c in columns:
            return c
    return None


def normalize(
    df: pd.DataFrame,
    *,
    taxon: str = "archaea_rel",
    reads: str = "auto",
) -> pd.DataFrame:
    """Normalize a sample-level table to the columns used by the models.

    Required output columns:
    sample, study, disease, y, det, reads, lg, st
    """
    out = df.copy()

    # Accept common synonyms without silently inventing values.
    if "study" not in out.columns:
        study_alias = _first_present(out.columns, ("study_name", "study_name_x", "cohort"))
        if study_alias:
            out["study"] = out[study_alias]
    if "disease" not in out.columns:
        disease_alias = _first_present(out.columns, ("condition", "phenotype", "group"))
        if disease_alias:
            out["disease"] = out[disease_alias]

    missing = [c for c in REQUIRED_COLUMNS if c not in out.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    if taxon not in out.columns:
        raise ValueError(f"Missing taxon column: {taxon!r}")

    if reads == "auto":
        read_col = _first_present(out.columns, READ_COLUMNS)
        if not read_col:
            raise ValueError(
                "No read-depth column found. Expected one of: "
                + ", ".join(READ_COLUMNS)
            )
    else:
        if reads not in out.columns:
            raise ValueError(f"Missing read-depth column: {reads!r}")
        read_col = reads

    out["sample"] = out["sample"].astype(str)
    out["study"] = out["study"].astype(str)
    out["disease"] = out["disease"].fillna("NA").astype(str).str.strip()

    if "st" not in out.columns:
        out["st"] = out["study"]
    out["st"] = (
        out["st"]
        .astype(str)
        .str.replace(r"^\d{4}-\d{2}-\d{2}\.", "", regex=True)
        .str.strip()
    )

    out["y"] = pd.to_numeric(out[taxon], errors="coerce").fillna(0.0)
    out["det"] = (out["y"] > 0).astype(int)
    out["reads"] = pd.to_numeric(out[read_col], errors="coerce")
    out["lg"] = np.log10(out["reads"].where(out["reads"] > 0))

    out = out.drop_duplicates("sample").copy()
    return out


def detection_summary(df: pd.DataFrame) -> dict:
    """Basic sample/study/detection counts."""
    if df.empty:
        return {
            "n_samples": 0,
            "n_studies": 0,
            "n_detected": 0,
            "detection_pct": 0.0,
            "n_with_reads": 0,
        }
    return {
        "n_samples": int(len(df)),
        "n_studies": int(df["st"].nunique()),
        "n_detected": int(df["det"].sum()),
        "detection_pct": round(float(df["det"].mean() * 100), 2),
        "n_with_reads": int(df["lg"].notna().sum()),
    }
