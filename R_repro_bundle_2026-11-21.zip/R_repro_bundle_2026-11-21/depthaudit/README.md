# DepthAudit

Depth-aware detection audit for microbiome–disease associations.

This is the reusable-tool layer extracted from the manuscript code
(`Additional_file_3.zip`). It is intentionally small: it reads a sample-level
abundance table, fits the depth–detection model, separates detection from
abundance conditional on detection, and writes a JSON/Markdown report.

## Install

```bash
python -m venv .venv
. .venv/bin/activate
pip install -e .
```

## Usage

```bash
depthaudit audit \
  --input dedup_analysis.csv \
  --taxon archaea_rel \
  --disease CRC \
  --disease IBD \
  --out results/
```

To assert the manuscript's headline numbers on the full dataset:

```bash
depthaudit audit \
  --input dedup_analysis.csv \
  --out results/ \
  --self-check
```

Input requirements:

- CSV or TSV;
- one row per sample (duplicates are dropped by `sample`);
- columns:
  - `sample`
  - `study` (or `study_name`)
  - `disease`
  - `archaea_rel` (or pass `--taxon`)
  - `number_reads` / `nr` / `reads` (or pass `--reads`)

Outputs:

- `results/results.json`
- `results/report.md`
- `results/study_effects_<DISEASE>.csv`

## What it computes

1. Detection summary: samples, studies, detection percentage.
2. Depth model: `det ~ log10(reads) + study fixed effects`; reports OR, 95% CI,
   p and pseudo-R².
3. Two-part detection: disease effect on detection (`det ~ disease + study`).
4. Full-scale and among-detected Hedges' g with random-effects pooling.

## R bridge

`scripts/export_cmd.R` converts the `curatedMetagenomicData` long table
(`EH_archaea_long.rds`) into the `EH_archaea_merged.csv` expected by this tool.
This bridge is the missing link in the original supplementary package.
If `curatedMetagenomicData` is not installed, the script can read an existing
`sampleMetadata.csv` instead.

## R verification

If you already have an `EH_archaea_long.rds` and `sampleMetadata.csv`:

```bash
Rscript scripts/export_cmd.R EH_archaea_merged.csv sampleMetadata.csv
python3 -m depthaudit audit --input EH_archaea_merged.csv \
  --out /tmp/depthaudit_verify --quiet --self-check
```

To regenerate the inputs from `curatedMetagenomicData`:

```bash
Rscript -e 'BiocManager::install("curatedMetagenomicData", ask=FALSE, update=FALSE)'
Rscript scripts/fetch_cmd.R
Rscript scripts/export_cmd.R EH_archaea_merged.csv sampleMetadata.csv
```

## Status

Prototype. It reproduces the original summary/depth/two-part models on
`dedup_analysis.csv`; it does not yet include the raw-read shell pipeline or
figure generation.

## License

MIT. See `LICENSE` (to be added before public release).
