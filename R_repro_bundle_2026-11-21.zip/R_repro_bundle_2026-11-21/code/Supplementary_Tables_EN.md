# Supplementary Tables

## Supplementary Table S2. Analytical validation and detection-limit benchmarks

**A. Control experiments**

| Control | Design | Result |
| --- | --- | --- |
| Negative control | 400,000 simulated 150-bp reads from ten gut bacterial genomes aligned to the archaeal index | 0 positive reads (false-positive rate 0.00%) |
| Positive control | 400,000 simulated archaeal reads aligned back to the index | 100.0% recovery |
| Spike-in recovery | Archaeal reads mixed into a bacterial background at 0.01%, 0.1% and 1% of reads at 25,000 / 100,000 / 500,000 reads, five replicates | 100% detection at every level and depth; detected counts matched expectation (50 vs 50 at 0.01% / 500,000 reads; 501 vs 501 at 0.1% / 500,000 reads) |
| Competitive alignment | 500,000 real CRC reads aligned to a combined archaeal + bacterial index | 91 archaeal vs 63,188 bacterial alignments |

**B. Threshold sensitivity at 500,000 reads**

| Positivity rule | Detection (%) |
| --- | --- |
| ≥1 read | 41 |
| ≥2 reads | 20 |
| ≥5 reads | 15 |
| ≥10 reads | 15 |
| ≥20 reads | 15 |

**C. Mapping-quality distribution (20 PRJEB10878 samples, 500,000 reads each; 39,778 archaeal reads)**

| MAPQ bin | Archaeal reads (%) |
| --- | --- |
| 0 | 0.85 |
| >0 and <10 | 3.76 |
| 10–20 | 0.13 |
| ≥20 | 95.26 |

CRC-to-control ratio: 62.3 with all reads versus 63.0 with MAPQ ≥20; mean archaeal reads per 500,000: CRC 3,730 vs control 59.

**D. MBARC-26 mock community**

| Metric | Value |
| --- | --- |
| Whole-genome archaeal fraction | 11.07% |
| 16S V3–V4 archaeal fraction | 10.03% |
| Relative recovery | ~91% |
| Depth stability | 10.73% at 25,000 reads to 11.09% at 1,000,000 reads |

**E. Analytical abundance benchmark (3/depth under a one-read positivity rule; the 25,000-read value is anchored by M. smithii spike-in)**

| Analysis depth (reads) | Minimum detectable abundance (%) |
| --- | --- |
| 25,000 | 0.012 |
| 100,000 | 0.003 |
| 500,000 | 0.0006 |
| 1,000,000 | 0.0003 |

All four values correspond to three expected reads (depth × abundance = 3). They are therefore an analytical 3/depth benchmark under a one-read positivity rule, not empirical 95% detection limits. Only the 25,000-read value is anchored by spike-in (five replicates); the five-replicate 0.01% spike at 25,000 reads (≈2.5 expected reads) is consistent with, but does not establish, a 95% detection probability.

**F. Detection by analysis depth in the downsampling experiment**

| Cohort | Analysis depth (reads) | n | Positive | Detection (%) | Wilson 95% CI |
| --- | --- | --- | --- | --- | --- |
| China | 25,000 | 115 | 18 | 15.7 | 10.1–23.4 |
| China | 50,000 | 115 | 19 | 16.5 | 10.8–24.4 |
| China | 100,000 | 115 | 23 | 20.0 | 13.7–28.2 |
| China | 250,000 | 115 | 31 | 27.0 | 19.7–35.7 |
| China | 500,000 | 105 | 46 | 43.8 | 34.7–53.4 |
| Japan | 25,000 | 100 | 14 | 14.0 | 8.5–22.1 |
| Japan | 50,000 | 100 | 18 | 18.0 | 11.7–26.7 |
| Japan | 100,000 | 100 | 22 | 22.0 | 15.0–31.1 |
| Japan | 250,000 | 100 | 26 | 26.0 | 18.4–35.4 |
| Japan | 500,000 | 100 | 39 | 39.0 | 30.0–48.8 |

Note. The 500,000-read bin for China contains 105 rather than 115 observations because ten runs retained fewer than 500,000 reads; percentages are simple proportions of the observations shown.

## Supplementary Table S3. Model and sensitivity statistics

**A. Sample-level detection model with study fixed effects (n = 21,385)**

| Parameter | Estimate |
| --- | --- |
| OR per log₁₀ reads (95% CI) | 2.96 (2.49–3.52) |
| β (SE) | +1.086 (0.088) |
| p | 6.0 × 10⁻³⁵ |
| pseudo-R² | 0.194 |
| Quadratic term (p) | 0.46 |
| Leave-one-study-out β range (median) | 0.805–1.301 (1.086) |
| Calibration slope / intercept | 0.70 / −0.30 |

**B. Unadjusted marginal model without study fixed effects (n = 18,924)**

| Parameter | Estimate |
| --- | --- |
| Intercept | −11.00 (0.44) |
| log₁₀ reads OR | 3.78 |
| Asia vs Europe/US OR | 0.35 |

**C. PRJNA763023 depth imbalance**

| Quantity | Value |
| --- | --- |
| Median depth, cases vs controls | 33,724 vs 54,137 reads |
| Depth OR per log₁₀ | 16.2 (p = 2.9 × 10⁻¹⁰) |
| Unadjusted detection contrast OR | 0.76 (p = 0.15) |
| Adjusted detection contrast OR | 0.91 (p = 0.62) |
| Abundance β, unadjusted → adjusted | 0.141 → 0.122 |

**D. Pseudocount sensitivity (1 × 10⁻⁶ → 1 × 10⁻²)**

| Phenotype | g (1e-6) | g (1e-2) |
| --- | --- | --- |
| CRC | +0.312 | +0.302 |
| IBD | −0.396 | −0.360 |

**E. Estimator comparison**

| Estimator | CRC g (95% CI) | IBD g (95% CI) |
| --- | --- | --- |
| DerSimonian–Laird (primary) | +0.312 (+0.136 to +0.488) | −0.396 (−0.672 to −0.120) |
| REML + HKSJ (sensitivity; t-based intervals, k−1 df) | +0.312 (+0.104 to +0.520) | −0.405 (−0.821 to +0.011) |
| Fixed effect (τ² = 0) | +0.231 | −0.343 |

**F. Functional pathway (METHANOGENESIS-PWY; 9 studies, 2,929 samples)**

| Metric | CRC | IBD | Healthy |
| --- | --- | --- | --- |
| Pathway positivity | 21.5% | 1.0% | 8.8% |
| Mean abundance ratio vs healthy | 2.93× | 0.34× | 1.00 |

**G. Literature-line counts**

| Item | n |
| --- | --- |
| Full texts assessed | 155 |
| Closely related / related / contextual / irrelevant | 72 / 37 / 42 / 4 |
| PICOS rows | 86 |
| RoB2 / ROBINS-E / QUADAS-2 / CARE | 7 / 53 / 8 / 3 |

**H. Mendelian randomisation**

| Phenotype | OR (95% CI) | Power at observed effect | Minimum detectable OR (80% power) |
| --- | --- | --- | --- |
| CRC | 1.06 (0.97–1.17) | 0.23 | 1.14 |
| IBD | 1.04 (0.95–1.13) | 0.23 | 1.14 |

**I. Akkermansia in IBD (detection fragility)**

| Study | Cases | Controls | Detection, cases vs controls | Prevalence OR | g (full scale) | g (among detected) |
| --- | --- | --- | --- | --- | --- | --- |
| HMP_2019_ibdmdb | 1201 | 426 | 24.9% vs 48.8% | 0.35 | −0.297 | 0.000 |
| HallAB_2017 | 185 | 74 | 40.0% vs 60.8% | 0.43 | −0.547 | −0.492 |
| IjazUZ_2017 | 56 | 38 | 16.1% vs 55.3% | 0.16 | −0.555 | −0.055 |
| NielsenHB_2014 | 148 | 248 | 31.8% vs 57.3% | 0.35 | −0.172 | +0.309 |
| Median | — | — | — | 0.35 | −0.42 | −0.03 |

**J. Archaea in IBD: abundance conditional on detection (per study)**

| Study | Detected cases | Detected controls | g among detected (SE) | Eligible for conditional-abundance analysis |
| --- | --- | --- | --- | --- |
| HMP_2019_ibdmdb | 55 | 61 | +0.472 (0.189) | Yes |
| NielsenHB_2014 | 44 | 39 | −0.013 (0.220) | Yes |
| HallAB_2017 | 6 | 1 | not estimable | No (controls <5) |
| IjazUZ_2017 | 4 | 16 | not estimable | No (cases <5) |
| LiJ_2014 | 26 | 4 | not estimable | No (controls <5) |
| IaniroG_2022 | 0 | 3 | not estimable | No (cases <5) |

Only two studies contributed at least five detected cases per group; no pooled conditional-abundance estimate is therefore reported (k<4 rule).

**K. Subject-level sensitivity analysis (one sample per subject)**

| Phenotype | Sample-level g (95% CI) | Subject-level g (95% CI) | Studies retained |
| --- | --- | --- | --- |
| CRC | +0.312 (+0.136 to +0.488) | +0.312 (+0.136 to +0.488) | 10 |
| IBD | −0.396 (−0.672 to −0.120) | −0.307 (−0.625 to +0.011) | 5 |

Note. For each study, one sample per subject was retained (first by sample identifier); 137 subject-groups contributing samples with conflicting disease labels were excluded from this sensitivity analysis.
