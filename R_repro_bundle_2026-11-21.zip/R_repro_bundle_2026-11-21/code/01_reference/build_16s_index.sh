#!/bin/bash
# Build the dual-domain 16S index (16s_dom_idx / 16s_arc_idx).
# Source: NCBI RefSeq Targeted Loci (Bacteria and Archaea 16S rRNA).
# The manuscript used the release with 26,876 bacterial and 1,160 archaeal
# sequences; counts drift between releases, so record the release date.
set -euo pipefail
source "$(dirname "$0")/../config.sh"
cd "$REF_DIR"
wget -q -c https://ftp.ncbi.nlm.nih.gov/refseq/TargetedLoci/Bacteria/bacteria.16SrRNA.fna.gz
wget -q -c https://ftp.ncbi.nlm.nih.gov/refseq/TargetedLoci/Archaea/archaea.16SrRNA.fna.gz
zcat bacteria.16SrRNA.fna.gz | awk '/^>/{print ">BACT|"$1"|"$0; next}{print}' > bact16s.fna
zcat archaea.16SrRNA.fna.gz | awk '/^>/{print ">ARCH|"$1"|"$0; next}{print}' > arch16s.fna
cat bact16s.fna arch16s.fna > 16s_domref.fna
cat arch16s.fna > 16s_arc.fna
bowtie2-build --threads "$THREADS" 16s_domref.fna 16s_dom_idx
bowtie2-build --threads "$THREADS" 16s_arc.fna 16s_arc_idx
echo "built 16s indices"
