#!/bin/bash
# Build the three-species archaeal bowtie2 index (arch_idx).
# Reference composition: M. smithii (NC_009515.1, 1 contig),
# M. stadtmanae MAG (NZ_CEVPIC..., 108 contigs), M. luminyensis MAG
# (NZ_CABLZR..., 26 contigs). Accessions are listed in contigs.tsv.
set -euo pipefail
source "$(dirname "$0")/../config.sh"
cd "$REF_DIR"
while IFS=$'\t' read -r acc species; do
  [ -z "$acc" ] && continue
  [ -s "${acc}.fa" ] && continue
  efetch -db nuccore -id "$acc" -format fasta > "${acc}.fa"
done < "$(dirname "$0")/contigs.tsv"
cat *.fa > archaea_all.fna
bowtie2-build --threads "$THREADS" archaea_all.fna arch_idx
echo "built $REF_DIR/arch_idx"
