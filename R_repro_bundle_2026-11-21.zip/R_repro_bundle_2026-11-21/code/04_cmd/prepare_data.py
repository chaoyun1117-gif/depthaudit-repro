# Build the de-duplicated analysis table used by all downstream scripts.
import pandas as pd, numpy as np
import os
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

d = pd.read_csv("EH_archaea_merged.csv", low_memory=False)
d["archaea_rel"] = pd.to_numeric(d["archaea_rel"], errors="coerce")
d = d.drop_duplicates("sample").copy()
d["st"] = d["study"].str.replace(r"^\d{4}-\d{2}-\d{2}\.", "", regex=True)
m = pd.read_csv("sampleMetadata.csv", low_memory=False)
m["nr"] = pd.to_numeric(m["number_reads"], errors="coerce")
m["nb"] = pd.to_numeric(m["number_bases"], errors="coerce")
m = m.drop_duplicates("sample_id")[["sample_id","nr","nb","country","sequencing_platform","DNA_extraction_kit","subject_id"]]
m = m.rename(columns={"sample_id":"sample"})
d = d.merge(m, on="sample", how="left")
d.to_csv("dedup_analysis.csv", index=False)
print("wrote dedup_analysis.csv:", len(d), "rows,", d["st"].nunique(), "studies")
