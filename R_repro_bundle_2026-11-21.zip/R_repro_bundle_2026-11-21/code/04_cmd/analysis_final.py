"""Final reproducible analysis on deduplicated curatedMetagenomicData.
Output: final_numbers.json + ledger printout."""
import pandas as pd, numpy as np, json, warnings
import statsmodels.formula.api as smf
warnings.filterwarnings("ignore")

OUT={}
d=pd.read_csv("EH_archaea_merged.csv",low_memory=False)
d["y"]=pd.to_numeric(d["archaea_rel"],errors="coerce").fillna(0)
d=d.drop_duplicates("sample").copy()
d["st"]=d["study"].str.replace(r"^\d{4}-\d{2}-\d{2}\.","",regex=True)
m=pd.read_csv("sampleMetadata.csv",low_memory=False)
for c in ["number_reads","number_bases","median_read_length"]: m[c]=pd.to_numeric(m[c],errors="coerce")
m=m.drop_duplicates("sample_id")[["sample_id","number_reads","number_bases","median_read_length","country","sequencing_platform","DNA_extraction_kit"]]
m=m.rename(columns={"country":"md_country","sequencing_platform":"md_platform","DNA_extraction_kit":"md_extract"})
d=d.merge(m,left_on="sample",right_on="sample_id",how="left")
d["det"]=(d.y>0).astype(int)
d["lg"]=np.log10(d.number_reads.where(d.number_reads>0))
d["st"]=d.st.astype(str)
OUT["n_samples"]=int(len(d)); OUT["n_studies"]=int(d.st.nunique())
OUT["detect_pct"]=round(float(d.det.mean()*100),2)
dd=d.dropna(subset=["lg"]).copy()
OUT["n_with_reads"]=int(len(dd))
def logit(formula,data):
    r=smf.logit(formula,data=data).fit(disp=0); return r
# 1 depth model
r1=logit("det ~ lg + C(st)",dd)
b,se=r1.params["lg"],r1.bse["lg"]
OUT["depth"]=dict(coef=round(b,4),se=round(se,4),OR=round(float(np.exp(b)),3),
    lo=round(float(np.exp(b-1.96*se)),3),hi=round(float(np.exp(b+1.96*se)),3),
    p=float(r1.pvalues["lg"]),pseudoR2=round(float(r1.prsquared),3))
# 2 quadratic
dd["lg2"]=dd.lg**2
r2=logit("det ~ lg + lg2 + C(st)",dd)
OUT["depth"]["quad_p"]=float(r2.pvalues["lg2"]); OUT["depth"]["quad_coef"]=round(float(r2.params["lg2"]),4)
# 3 LOO
lo=[]
for s in dd.st.unique():
    try:
        rr=logit("det ~ lg + C(st)",dd[dd.st!=s]); lo.append(rr.params["lg"])
    except Exception: pass
OUT["depth"]["loo_min"]=round(float(min(lo)),3); OUT["depth"]["loo_max"]=round(float(max(lo)),3)
OUT["depth"]["loo_median"]=round(float(np.median(lo)),3)
# 4 region / platform / extraction (one-covariate)
OUT["region_n"]=int(dd["md_country"].notna().sum())
def onecov(col,tag):
    try:
        rr=logit(f"det ~ {col} + C(st)",data=dd.assign(**{col:dd[col].astype(str)}))
        s=pd.Series({k:round(float(np.exp(v)),3) for k,v in rr.params.items() if k.startswith(col)})
        return s.to_dict()
    except Exception as e: return {"ERR":str(e)}
# 5 effects
def hedges(a,b):
    n1,n2=len(a),len(b)
    if n1<3 or n2<3: return np.nan,np.nan
    s1,s2=a.std(ddof=1),b.std(ddof=1)
    sp=np.sqrt(((n1-1)*s1**2+(n2-1)*s2**2)/(n1+n2-2))
    if sp==0 or np.isnan(sp): return np.nan,np.nan
    g=(a.mean()-b.mean())/sp*(1-3/(4*(n1+n2)-9))
    return g,np.sqrt((n1+n2)/(n1*n2)+g**2/(2*(n1+n2)))
def dl(gs,vs):
    gs=np.array(gs,float); vs=np.array(vs,float); ok=(~np.isnan(gs))&(~np.isnan(vs)); gs,vs=gs[ok],vs[ok]
    if len(gs)==0: return None
    w=1/vs; Q=float((w*(gs-(w*gs).sum()/w.sum())**2).sum()); C=w.sum()-(w**2).sum()/w.sum()
    tau2=max(0,(Q-(len(gs)-1))/C) if C>0 else 0; wr=1/(vs+tau2)
    mu=float((wr*gs).sum()/wr.sum()); s=float(np.sqrt(1/wr.sum()))
    return dict(k=int(len(gs)),g=round(mu,3),lo=round(mu-1.96*s,3),hi=round(mu+1.96*s,3),
                I2=round(max(0,(Q-(len(gs)-1))/Q*100),1) if Q>0 else 0.0,tau2=round(tau2,4))
eff={}
for lab in ["CRC","IBD"]:
    sub=d[d.disease.isin([lab,"healthy"])]
    gf=[];vf=[];gp=[];vp=[];rows=[]
    for st,g in sub.groupby("st"):
        c=g[g.disease==lab]; k=g[g.disease=="healthy"]
        if len(c)<5 or len(k)<5: continue
        a,sa=hedges(np.log10(c.y+1e-6).values,np.log10(k.y+1e-6).values)
        cp=c[c.y>0]; kp=k[k.y>0]
        b_,sb=(hedges(np.log10(cp.y).values,np.log10(kp.y).values) if len(cp)>=5 and len(kp)>=5 else (np.nan,np.nan))
        gf.append(a);vf.append(sa**2 if not np.isnan(sa) else np.nan)
        gp.append(b_);vp.append(sb**2 if not np.isnan(sb) else np.nan)
        rows.append(dict(study=st,n_case=len(c),n_ctrl=len(k),g_all=a,g_pos=b_))
    eff[lab]=dict(full=dl(gf,vf),pos=dl(gp,vp),rows=rows)
OUT["effects"]=eff
# 6 two-part
tp={}
for lab in ["CRC","IBD"]:
    sub=d[d.disease.isin([lab,"healthy"])].dropna(subset=["lg"]).copy(); sub["case"]=(sub.disease==lab).astype(int)
    mm=logit("det ~ case + C(st)",sub); c_,s_=mm.params["case"],mm.bse["case"]
    tp[lab]=dict(OR=round(float(np.exp(c_)),3),lo=round(float(np.exp(c_-1.96*s_)),3),
                 hi=round(float(np.exp(c_+1.96*s_)),3),p=float(mm.pvalues["case"]))
OUT["twopart_detection"]=tp
# 7 depth adjustment (log10 abundance)
adj={}
for lab in ["CRC","IBD"]:
    sub=d[d.disease.isin([lab,"healthy"])].dropna(subset=["lg"]).copy(); sub["case"]=(sub.disease==lab).astype(int)
    sub["pos"]=np.log10(sub.y+1e-6)
    a=smf.ols("pos ~ case + C(st)",sub).fit(); b_=smf.ols("pos ~ case + lg + C(st)",sub).fit()
    adj[lab]=dict(unadj=round(float(a.params["case"]),4),adj=round(float(b_.params["case"]),4),
                  pct=round(float((b_.params["case"]-a.params["case"])/abs(a.params["case"])*100),1))
OUT["depth_adjust"]=adj
json.dump(OUT,open("final_numbers.json","w"),indent=1,default=float)
print(json.dumps({k:v for k,v in OUT.items() if k!="effects"},indent=1,default=float))
for lab in ["CRC","IBD"]:
    e=eff[lab]; print(f"\n{lab}: full scale {e['full']}"); print(f"       among detected {e['pos']}")
