#!/bin/bash
# Usage: download_reads.sh <manifest.tsv> [dest_dir]
# Manifest columns: group <TAB> run <TAB> url [<TAB> extra]
set -euo pipefail
source "$(dirname "$0")/../config.sh"
MANIFEST="$1"; DEST="${2:-$DATA_DIR}"; mkdir -p "$DEST"
while IFS=$'\t' read -r grp run url extra; do
  [ -z "${run:-}" ] && continue
  case "$url" in http*) full="$url" ;; *) full="https://$url" ;; esac
  out="$DEST/${run}.fastq.gz"
  if [ -s "$out" ] && gzip -t "$out" 2>/dev/null; then echo "skip $run"; continue; fi
  echo "download $run"
  wget -q -c -O "$out" "$full" || curl -sL --retry 3 -C - -o "$out" "$full"
  gzip -t "$out" || { echo "ERROR: corrupted $run"; exit 1; }
done < "$MANIFEST"
echo "done -> $DEST"
