# Download manifests
Each file has columns: `group <TAB> run <TAB> url [<TAB> extra]`.
Use `00_download/download_reads.sh <manifest>` to fetch the FASTQ files.

| File | Cohort | Accession |
| --- | --- | --- |
| PRJEB10878_China_CRC.tsv | China CRC (deep WGS) | PRJEB10878 |
| PRJDB4176_Japan_CRC.tsv | Japan CRC/adenoma | PRJDB4176 |
| PRJNA385949_Hall_IBD.tsv | Hall IBD | PRJNA385949 |
| PRJEB1220_MetaHIT_IBD.tsv | MetaHIT IBD | PRJEB1220 |
| PRJNA398089_HMP2_IBD.tsv | HMP2 IBD | PRJNA398089 |
| PRJNA422434_China_T2D.tsv | China T2D | PRJNA422434 |
| PRJDB11845_Japan_CRC_16S.tsv | Japan CRC 16S | PRJDB11845 |
| PRJDB16834_Japan_Adenoma_16S.tsv | Japan adenoma 16S | PRJDB16834 |
| Vogtmann_IBD.tsv | Vogtmann IBD | Vogtmann cohort |
| 16S_multi_project.tsv | Four 16S projects (column 4 = accession) | PRJEB53891 / PRJNA763023 / PRJDB16834 / PRJDB11845 |

PRJEB12449 was screened but yielded ~0 archaeal reads and was therefore excluded from pooling; no manifest is provided.
