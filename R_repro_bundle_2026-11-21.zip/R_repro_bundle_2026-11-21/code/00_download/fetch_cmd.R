# Fetch curatedMetagenomicData exports used by the quantitative line.
# Requires Bioconductor >= 3.18 and curatedMetagenomicData >= 3.6.
# The study used two snapshots; pin the ExperimentHub snapshot date in your
# installation (see https://bioconductor.org/packages/curatedMetagenomicData/).
suppressPackageStartupMessages({
  library(curatedMetagenomicData)
  library(ExperimentHub)
})
# 1) Sample metadata
sm <- sampleMetadata
write.csv(sm, "sampleMetadata.csv", row.names = FALSE)
# 2) Relative abundances (MetaPhlAn) for the archaeal genera
taxa <- c("k__Archaea", "g__Methanobrevibacter", "g__Methanosphaera",
          "g__Methanomassiliicoccus", "g__Methanobacterium")
expr <- curatedMetagenomicData(paste0(taxa, ".relative_abundance"),
                               dryrun = FALSE, counts = FALSE, rownames = "long")
# Combine into one table: sample, disease, archaea_rel, genus columns
# (the exact merge is in 04_cmd/prepare_data.py; this script only exports
#  the long-format table expected by that step)
saveRDS(expr, "EH_archaea_long.rds")
message("Wrote sampleMetadata.csv and EH_archaea_long.rds")
