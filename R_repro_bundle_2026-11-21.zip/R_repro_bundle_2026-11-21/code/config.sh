#!/bin/bash
# Central configuration. Source this file before running any step.
export PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export DATA_DIR="${DATA_DIR:-$PROJECT_ROOT/data}"          # downloaded FASTQ
export REF_DIR="${REF_DIR:-$PROJECT_ROOT/reference}"       # bowtie2 indices
export OUT_DIR="${OUT_DIR:-$PROJECT_ROOT/results}"         # raw-read outputs
export THREADS="${THREADS:-4}"
mkdir -p "$DATA_DIR" "$REF_DIR" "$OUT_DIR"
