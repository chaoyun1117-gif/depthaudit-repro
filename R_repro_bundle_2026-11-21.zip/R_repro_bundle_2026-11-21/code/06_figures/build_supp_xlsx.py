import re, csv
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
md=open("Supplementary_Tables_EN.md",encoding="utf-8").read()
wb=Workbook(); wb.remove(wb.active)
HDR_FILL=PatternFill("solid",fgColor="DCE6F1"); PANEL_FILL=PatternFill("solid",fgColor="F2F2F2")
THIN=Side(style="thin",color="BFBFBF"); BORDER=Border(left=THIN,right=THIN,top=THIN,bottom=THIN)
BOLD=Font(bold=True,size=10); NORM=Font(size=10); TITLE=Font(bold=True,size=11,color="1F4E79")
def parse_table(lines):
    rows=[]
    for ln in lines:
        t=ln.strip()
        if t.startswith("|"):
            cells=[c.strip() for c in t.strip("|").split("|")]
            if all(set(c)<=set("-: ") for c in cells): continue
            rows.append(cells)
    return rows
def write_sheet(name,panels):
    ws=wb.create_sheet(name); r=1
    for title,lines in panels:
        ws.cell(r,1,title).font=TITLE; ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=6)
        ws.cell(r,1).fill=PANEL_FILL; r+=1
        rows=parse_table(lines)
        for ri,row in enumerate(rows):
            for ci,v in enumerate(row,1):
                c=ws.cell(r,ci,v); c.font=BOLD if ri==0 else NORM; c.border=BORDER
                c.alignment=Alignment(wrap_text=True,vertical="top")
                if ri==0: c.fill=HDR_FILL
            r+=1
        for ln in lines:
            t=ln.strip()
            if t and not t.startswith("|") and not t.startswith("**") and len(t)>25:
                ws.cell(r,1,t).font=Font(size=9,italic=True)
                ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=6)
                ws.cell(r,1).alignment=Alignment(wrap_text=True,vertical="top"); r+=1
        r+=2
    for i in range(1,7): ws.column_dimensions[get_column_letter(i)].width=[26,14,14,22,18,26][i-1]
def section(start,end):
    i=md.find(start); j=md.find(end) if end else len(md); body=md[i:j]
    parts=re.split(r"(?m)^\*\*([A-J])\. (.*)\*\*$",body); panels=[]
    for k in range(1,len(parts),3): panels.append(("%s. %s"%(parts[k],parts[k+1].strip()),parts[k+2].split("\n")))
    return panels
write_sheet("S2",section("## Supplementary Table S2","## Supplementary Table S3"))
write_sheet("S3",section("## Supplementary Table S3",None))
rows=list(csv.reader(open("cohort_overlap.csv",encoding="utf-8")))
ws=wb.create_sheet("S1_cohort_overlap",0)
ws.cell(1,1,"Supplementary Table S1. Cohort overlap between the quantitative and raw-read lines (source table in Chinese)").font=TITLE
ws.merge_cells(start_row=1,start_column=1,end_row=1,end_column=max(len(r) for r in rows))
for ri,row in enumerate(rows,2):
    for ci,v in enumerate(row,1):
        c=ws.cell(ri,ci,v); c.border=BORDER; c.font=BOLD if ri==2 else NORM
        c.alignment=Alignment(wrap_text=True,vertical="top")
        if ri==2: c.fill=HDR_FILL
for i in range(1,max(len(r) for r in rows)+1): ws.column_dimensions[get_column_letter(i)].width=24
ws=wb.create_sheet("README",0)
ws.cell(1,1,"Supplementary Tables (Excel)").font=Font(bold=True,size=14)
for i,t in enumerate(["Workbook contents","","S1_cohort_overlap — cohort overlap between the quantitative and raw-read lines.","S2 — Analytical validation and detection-limit benchmarks (panels A–E).","S3 — Model and sensitivity statistics (panels A–J).","","Notes","• S2E is a 3/depth analytical benchmark; only the 25,000-read value is anchored by spike-in.","• S3A is a sample-level model with study fixed effects (n = 21,385).","• S3E uses t-based HKSJ intervals (k−1 df); the IBD interval includes zero.","• S3J lists per-study conditional-abundance estimates; only two studies met the ≥5 detected per group requirement."],3):
    ws.cell(i,1,t).font=Font(size=10,bold=(i==3))
ws.column_dimensions["A"].width=120
wb.save("Supplementary_Tables_EN.xlsx"); print("xlsx rebuilt",wb.sheetnames)
