# -*- coding: utf-8 -*-
"""v3 figure set: 6 results figures + 2 supplementary.
PRISMA -> S1; MR/power -> S2; new main-proposition figure = F2;
F2+F4 merged into F3; MAPQ = F5."""
import json, math, csv, os
import os
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from collections import defaultdict
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle
from scipy import stats

W=170/25.4; FS=9.0
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":FS,"axes.titlesize":FS,
 "axes.labelsize":FS,"axes.labelweight":"bold","xtick.labelsize":FS,"ytick.labelsize":FS,
 "legend.fontsize":6.5,"axes.linewidth":0.6,"xtick.major.width":0.6,"ytick.major.width":0.6,
 "figure.dpi":600,"savefig.dpi":600,"figure.facecolor":"white","savefig.facecolor":"white"})
OUT="figures/"
os.makedirs(OUT, exist_ok=True)
P=json.load(open("pool_v3.json")); FN=json.load(open("final_numbers.json"))
def lab(ax,s): ax.set_title(s,loc="left",fontweight="bold",color="#1f4e79",pad=3)
def save(fig,name):
    fig.savefig(OUT+name,dpi=600,facecolor="white")
    fig.savefig(OUT+name.replace(".png",".pdf"),format="pdf",facecolor="white")
    plt.close(fig); print("wrote",name)

# ============================ F1 : detection landscape (A phenotype, B dataset spread, C DNA/RNA) ============================
d=pd.read_csv("dedup_analysis.csv",low_memory=False)
d["y"]=pd.to_numeric(d.archaea_rel,errors="coerce").fillna(0)
d["lg"]=np.log10(d.nr.where(d.nr>0))
g=d.groupby("st").agg(det=("y",lambda s:(s>0).mean()*100),n=("y","size"),depth=("lg","median")).query("n>=10").sort_values("det")
fig=plt.figure(figsize=(W,3.7))
gs=fig.add_gridspec(1,3,width_ratios=[1.25,1.0,0.72],wspace=0.52,left=0.075,right=0.975,top=0.90,bottom=0.28)
ax=fig.add_subplot(gs[0,0])
pheno=[("IGT",38),("T2D",30),("CRC",29),("Adenoma",29),("CVD",20),("IBD",8),("Hypertension",3)]
ax.bar(range(len(pheno)),[p[1] for p in pheno],color="#2c5f8a",edgecolor="#1f4e79",lw=0.5,width=0.70)
ax.set_xticks(range(len(pheno))); ax.set_xticklabels([p[0] for p in pheno],rotation=45,ha="right")
ax.set_ylabel("reported methane positivity (%)"); ax.set_ylim(0,46)
for i,p in enumerate(pheno): ax.text(i,p[1]+0.8,str(p[1]),ha="center",fontsize=FS)
lab(ax,"A")
ax2=fig.add_subplot(gs[0,1])
sc=ax2.scatter(g.det,range(len(g)),c=g.depth,s=12,cmap="Blues",vmin=5,vmax=8.5,edgecolor="#1f4e79",linewidth=0.3)
ax2.set_xlabel("archaeal detection per dataset (%)"); ax2.set_yticks([]); ax2.set_xlim(0,100); ax2.set_ylabel("datasets (sorted)",labelpad=2)
lab(ax2,"B")
cb=fig.colorbar(sc,ax=ax2,fraction=0.06,pad=0.03); cb.set_label("log$_{10}$ reads",fontsize=6.5); cb.ax.tick_params(labelsize=6.5)
ax2.annotate("%.1f%%"%g.det.min(),xy=(g.det.min(),0),xytext=(6,6),textcoords="offset points",fontsize=6.5)
ax2.annotate("%.1f%%"%g.det.max(),xy=(g.det.max(),len(g)-1),xytext=(-36,-6),textcoords="offset points",fontsize=6.5)
ax3=fig.add_subplot(gs[0,2])
ax3.bar([0,1],[1.0,2.7],color=["#2c5f8a","#7aa3c7"],edgecolor="#1f4e79",lw=0.5,width=0.6)
ax3.set_xticks([0,1]); ax3.set_xticklabels(["DNA","RNA"],fontsize=6.5); ax3.set_ylabel("HMP2 samples (%)"); ax3.set_ylim(0,3.4)
for x_,v in zip([0,1],[1.0,2.7]): ax3.text(x_,v+0.08,"%.1f%%"%v,ha="center",fontsize=FS)
lab(ax3,"C")
save(fig,"Figure 1.png")

# ============================ F2 : analytical validation & detection limits ============================
mq=pd.read_csv("mapq_sens_results.tsv",sep="\t",header=None,
               names=["grp","run","tot","n","z","l","m","h"])
tot=mq[["z","l","m","h"]].sum()
fig=plt.figure(figsize=(W,4.6))
gs=fig.add_gridspec(2,2,hspace=0.52,wspace=0.30,left=0.10,right=0.975,top=0.92,bottom=0.12)
ax=fig.add_subplot(gs[0,0])
vals=[tot["z"]/tot.sum()*100,tot["l"]/tot.sum()*100,tot["m"]/tot.sum()*100,tot["h"]/tot.sum()*100]
ax.bar(range(4),vals,color=["#c9c9c9","#9ecae1","#5b8db8","#1f4e79"],edgecolor="#1f4e79",lw=0.4,width=0.68)
ax.set_xticks(range(4)); ax.set_xticklabels(["MQ=0","<10","10\u201320","\u226520"],fontsize=6.5)
ax.set_ylabel("archaeal reads (%)"); ax.set_ylim(0,105)
for i,v in enumerate(vals): ax.text(i,v+2,"%.1f"%v,ha="center",fontsize=6.5)
lab(ax,"A")
axB=fig.add_subplot(gs[0,1])
axB.bar([0,1],[62.3,63.0],color=["#9ecae1","#2c5f8a"],edgecolor="#1f4e79",lw=0.4,width=0.55)
axB.set_xticks([0,1]); axB.set_xticklabels(["all reads","MQ\u226520"],fontsize=6.5)
axB.set_ylabel("CRC/control ratio"); axB.set_ylim(0,78)
for i,v in enumerate([62.3,63.0]): axB.text(i,v+1.6,"%.1f"%v,ha="center",fontsize=FS)
lab(axB,"B")
axC=fig.add_subplot(gs[1,0])
thr=["\u22651","\u22652","\u22655","\u226510","\u226520"]; tv=[41,20,15,15,15]
axC.bar(range(5),tv,color="#2c5f8a",edgecolor="#1f4e79",lw=0.4,width=0.62)
axC.set_xticks(range(5)); axC.set_xticklabels(thr,fontsize=6.5)
axC.set_xlabel("positivity rule (reads)"); axC.set_ylabel("detection (%)"); axC.set_ylim(0,50)
for i,v in enumerate(tv): axC.text(i,v+1,"%d"%v,ha="center",fontsize=6.5)
lab(axC,"C")
axD=fig.add_subplot(gs[1,1])
dep=[2.5e4,1e5,5e5,1e6]; mda=[0.012,0.003,0.0006,0.0003]
axD.plot(dep,mda,"o-",color="#2c5f8a",lw=1.1,ms=3.8)
axD.set_xscale("log"); axD.set_yscale("log")
axD.set_xlabel("analysis depth (reads)"); axD.set_ylabel("MDA (%)")
axD.set_xlim(1.5e4,2.2e6)
for i,(x_,y_) in enumerate(zip(dep,mda)):
    off=(-28,6) if i==len(dep)-1 else (6,6); ha="right" if i==len(dep)-1 else "left"
    axD.annotate("%.4g"%y_,xy=(x_,y_),xytext=off,textcoords="offset points",fontsize=6.0,ha=ha)
lab(axD,"D")
save(fig,"Figure 2.png")

# ============================ F3 : detection attenuation (merged) ============================
fig=plt.figure(figsize=(W,5.4))
gs=fig.add_gridspec(2,2,hspace=0.42,wspace=0.28,left=0.085,right=0.985,top=0.94,bottom=0.09)
data=[("PRJEB10878","WGS",5.9e7,66),("PRJDB4176","WGS",4.4e7,28),("PRJNA385949","WGS",3.0e7,21),
 ("PRJEB1220","WGS",5.7e7,91),("PRJNA398089","WGS",2.3e7,10),("PRJEB53891","16S",1.8e5,100),
 ("PRJDB16834","16S",4.8e6,100),("PRJNA763023","16S",5.5e4,12),("PRJDB11845","16S",3.6e4,0)]
ax=fig.add_subplot(gs[0,0]); col={"WGS":"#2c5f8a","16S":"#c0392b"}
for l,t,dd,det in data: ax.scatter(dd,det,color=col[t],s=24,marker=("o" if t=="WGS" else "^"))
for t in ["WGS","16S"]: ax.scatter([],[],color=col[t],s=24,marker=("o" if t=="WGS" else "^"),label=t)
ax.set_xscale("log"); ax.set_xlabel("sequencing depth (median reads)"); ax.set_ylabel("archaeal detection (%)")
ax.set_ylim(-6,106); ax.legend(frameon=False); lab(ax,"A")
rows=list(csv.DictReader(open("da2_results.tsv"),delimiter="\t"))
by=defaultdict(lambda: defaultdict(list))
for r in rows: by[(r["study"],r["depth_rep"].split("_")[0])][r["grp"]].append(float(r["arch"]))
order_d=["25k","50k","100k","250k","500k"]; labs={"P10878":"China","PDB4176":"Japan"}
def gval(a,b):
    a=np.array(a);b=np.array(b)
    if len(a)<2 or len(b)<2: return (np.nan,np.nan)
    n1,n2=len(a),len(b); s1,s2=a.std(ddof=1),b.std(ddof=1)
    sp=math.sqrt(((n1-1)*s1*s1+(n2-1)*s2*s2)/(n1+n2-2))
    if sp==0: return (0.0,0.0)
    g=(a.mean()-b.mean())/sp*(1-3/(4*(n1+n2)-9)); return g,math.sqrt((n1+n2)/(n1*n2)+g*g/(2*(n1+n2)))
axB=fig.add_subplot(gs[0,1]); axC=fig.add_subplot(gs[1,0])
for st in ["P10878","PDB4176"]:
    xs=[];det=[];gv=[];gsd=[]
    for i,dl in enumerate(order_d):
        grp=by.get((st,dl))
        if not grp: continue
        tot=sum(len(v) for v in grp.values()); pos=sum(1 for v in grp.get("case",[]) if v>=1)+sum(1 for v in grp.get("control",[]) if v>=1)
        det.append(100*pos/tot); xs.append(i)
        g_,s_=gval(np.log10(np.array(grp.get("case",[0]))+1e-6),np.log10(np.array(grp.get("control",[0]))+1e-6))
        gv.append(g_); gsd.append(s_)
    axB.plot(xs,det,"o-",lw=1.0,ms=3.5,label=labs[st])
    axC.errorbar(xs,gv,yerr=[1.96*s for s in gsd],fmt="o-",lw=1.0,ms=3.5,capsize=2,label=labs[st])
for a,xl,yl in [(axB,"analysis depth (reads)","detection (%)"),(axC,"analysis depth (reads)","Hedges' g (CRC vs control)")]:
    a.set_xticks(range(5)); a.set_xticklabels(order_d); a.set_xlabel(xl); a.set_ylabel(yl); a.legend(frameon=False,fontsize=6.5)
axC.axhline(0,color="#999",lw=0.5,ls=":"); lab(axB,"B"); lab(axC,"C")
# D model curve + real depth distribution
xr=[r for r in csv.DictReader(open("16s_full_results.tsv"),delimiter="\t") if r["status"]=="OK"]
axD=fig.add_subplot(gs[1,1])
xs=np.logspace(3,9,300); p=1/(1+np.exp(-(-9.7413+1.1616*np.log10(xs))))
axD.plot(xs,p*100,color="#2c5f8a",lw=1.2)
axD.set_xscale("log"); axD.set_xlabel("sequencing depth (reads)"); axD.set_ylabel("predicted detection (%)"); axD.set_ylim(0,100)
d2=pd.read_csv("dedup_analysis.csv",low_memory=False)
d2["lg"]=np.log10(pd.to_numeric(d2.nr,errors="coerce").where(lambda x:x>0))
lo,hi=d2.lg.quantile(.05),d2.lg.quantile(.95)
axD.axvspan(10**lo,10**hi,color="#2c5f8a",alpha=0.13,lw=0)
pl=1/(1+np.exp(-(-9.7413+1.1616*lo)))*100; ph=1/(1+np.exp(-(-9.7413+1.1616*hi)))*100
axD.annotate("95%% of datasets\n%.0f–%.0f%% predicted"%(pl,ph),xy=(10**((lo+hi)/2),(pl+ph)/2),xytext=(10**(lo-1.05),72),
             fontsize=6.5,color="#1f4e79",arrowprops=dict(arrowstyle="-",lw=0.6,color="#1f4e79"))
lab(axD,"D")

save(fig,"Figure 3.png")

# ============================ F4 : forests ============================
fig=plt.figure(figsize=(W,5.6))
gsA=fig.add_gridspec(1,1,left=0.34,right=0.985,top=0.95,bottom=0.66)
axA=fig.add_subplot(gsA[0]); order=[k for k in ["CRC","IBD","Adenoma","T2D"] if P.get(k,{}).get("g") is not None]
y=0;yt=[];yl=[]
for k in order:
    v=P[k]; axA.plot([v["lo"],v["hi"]],[y,y],color="#333",lw=0.9); axA.plot(v["g"],y,"D",color="#c0392b",ms=4)
    yt.append(y); yl.append("%s  k=%d  I²=%.0f%%"%(k,v["k"],v["I2"])); y-=1
axA.axvline(0,color="#999",lw=0.6,ls="--"); axA.set_yticks(yt); axA.set_yticklabels(yl)
for t in axA.get_yticklabels(): t.set_fontweight("bold")
axA.set_xlabel("Hedges' g (disease vs healthy)"); lab(axA,"A")
axA.text(0.99,-0.34,"k≤3 not pooled: IGT (k=3), ACVD (k=1), MS (k=1), hypertension (k=0)",
         transform=axA.transAxes,ha="right",va="top",fontsize=6.0,color="#666")
gs2=fig.add_gridspec(1,3,left=0.20,right=0.935,top=0.50,bottom=0.09,wspace=0.80)
def forest(ax,rows_,letter,xlab="Hedges' g"):
    it=sorted([r for r in rows_ if r.get("g") is not None],key=lambda r:r["g"])
    y=0;yt=[];yl=[]
    for r in it:
        ax.plot([r["g"]-1.96*r["se"],r["g"]+1.96*r["se"]],[y,y],color="#2c5f8a",lw=0.7)
        ax.plot(r["g"],y,"o",color="#2c5f8a",ms=3); yt.append(y); yl.append(r["study"]); y-=1
    ax.axvline(0,color="#999",lw=0.6,ls="--"); ax.set_yticks(yt); ax.set_yticklabels(yl,fontsize=6.5)
    for t in ax.get_yticklabels(): t.set_fontweight("bold")
    ax.set_xlabel(xlab); lab(ax,letter)
forest(fig.add_subplot(gs2[0]),P["CRC"]["rows"],"B")
forest(fig.add_subplot(gs2[1]),P["IBD"]["rows"],"C")
wr=[("PRJEB10878 CRC (China)",0.315,0.0139),("PRJDB4176 CRC (Japan)",0.158,0.0227),("PRJDB4176 Adenoma",0.242,0.0123),
 ("FengQ_2015 CRC",0.660,0.001),("HanniganGD_2017 CRC",0.345,0.20),("WirbelJ_2018 CRC",0.051,0.84),
 ("ZellerG_2014 CRC",0.042,0.82),("PRJEB1220 IBD",-0.130,0.097),("PRJNA385949 IBD",0.084,0.373)]
def se_from_p(g,p): 
    z=stats.norm.isf(p/2); return abs(g)/z if z else 0
axD=fig.add_subplot(gs2[2])
items=[(n,g,se_from_p(g,pv)) for n,g,pv in wr]+[("Pooled CRC",0.265,(0.438-0.093)/(2*1.96))]
y=0;yt=[];yl=[]
for n,g,se in items:
    pooled=n.startswith("Pooled")
    axD.plot([g-1.96*se,g+1.96*se],[y,y],color=("#000" if pooled else "#2c5f8a"),lw=(1.0 if pooled else 0.7))
    axD.plot(g,y,("D" if pooled else "o"),color=("#c0392b" if pooled else "#2c5f8a"),ms=(4 if pooled else 3))
    yt.append(y); yl.append(n); y-=1
axD.axvline(0,color="#999",lw=0.6,ls="--"); axD.set_yticks(yt); axD.set_yticklabels(yl,fontsize=6.5)
for t,l in zip(axD.get_yticklabels(),yl):
    if l.startswith("Pooled"): t.set_fontweight("bold")
axD.set_xlabel("Hedges' g"); lab(axD,"D")
save(fig,"Figure 4.png")

# ============================ F5 : two-part decomposition and cross-genus ============================
fig=plt.figure(figsize=(W,4.2))
gs=fig.add_gridspec(1,3,width_ratios=[1.15,1.0,1.0],wspace=0.55,left=0.085,right=0.975,top=0.88,bottom=0.24)
# A slope: full-scale vs among-detected (IBD not pooled, k=2)
ax=fig.add_subplot(gs[0,0])
for name,col,full,flo,fhi,pos,plo,phi,pooled in [
    ("CRC","#2c5f8a",0.312,0.136,0.488,0.108,-0.223,0.439,True),
    ("IBD","#c0392b",-0.396,-0.672,-0.120,None,None,None,False)]:
    ax.plot(0,full,"o",color=col,ms=4,label=name)
    ax.vlines(0,flo,fhi,color=col,lw=0.8)
    if pooled:
        ax.plot([0,1],[full,pos],"-",color=col,lw=1.1)
        ax.plot(1,pos,"o",color=col,ms=4)
        ax.vlines(1,plo,phi,color=col,lw=0.8)
        ax.annotate("",xy=(1,pos),xytext=(0.86,full),arrowprops=dict(arrowstyle="-|>",color=col,lw=0.9,shrinkA=2,shrinkB=2))
ax.text(1,-0.20,"Not pooled\n(k=2)",ha="center",va="top",fontsize=6.5,color="#c0392b")
ax.axhline(0,color="#999",lw=0.6,ls="--")
ax.set_xticks([0,1]); ax.set_xticklabels(["full-scale\ng (incl. zeros)","g among\ndetected"],fontsize=FS)
ax.set_ylabel("Hedges' g"); ax.set_xlim(-0.25,1.25); ax.legend(frameon=False,loc="lower left")
lab(ax,"A")

# B Akkermansia dumbbell
b2=pd.read_csv("b2_genus_per_study.csv")
ak=b2[b2.genus=="Akkermansia"].copy()
axB=fig.add_subplot(gs[0,1])
rows=list(zip(ak.study,ak.g_all,ak.g_amongpos))
rows.append(("median",float(np.median(ak.g_all)),float(np.median(ak.g_amongpos))))
for i,(s,a,b) in enumerate(rows):
    bold = s=="median"
    axB.plot([a,b],[i,i],color=("#1f4e79" if bold else "#bbb"),lw=(1.2 if bold else 0.8),zorder=1)
    axB.scatter(a,i,color="#2c5f8a",s=(26 if bold else 16),zorder=2,edgecolor="k",linewidth=(0.6 if bold else 0.3))
    axB.scatter(b,i,color="#e08a2e",s=(26 if bold else 16),zorder=2,edgecolor="k",linewidth=(0.6 if bold else 0.3))
axB.axvline(0,color="#999",lw=0.6,ls="--")
axB.set_yticks(range(len(rows))); axB.set_yticklabels([r[0] for r in rows],fontsize=6.5)
for t in axB.get_yticklabels()[-1:]: t.set_fontweight("bold")
axB.set_xlabel("Hedges' g"); lab(axB,"B")
axB.set_ylim(-0.7,5.4)
axB.annotate("full-scale",xy=(rows[-1][1],len(rows)-1),xytext=(0,10),textcoords="offset points",fontsize=6.0,color="#2c5f8a",ha="center")
axB.annotate("among detected",xy=(rows[-1][2],len(rows)-1),xytext=(0,26),textcoords="offset points",fontsize=6.0,color="#e08a2e",ha="center")
# C other genera
axC=fig.add_subplot(gs[0,2])
oth=[("Barnesiella",-0.31,0.01),("Coprobacter",-0.31,0.00),("Odoribacter",-0.30,0.05),("Oscillibacter",-0.30,0.15),("Bilophila",-0.23,0.09)]
for i,(s,a,b) in enumerate(oth):
    axC.plot([a,b],[i,i],color="#bbb",lw=0.8,zorder=1)
    axC.scatter(a,i,color="#2c5f8a",s=16,zorder=2); axC.scatter(b,i,color="#e08a2e",s=16,zorder=2)
axC.axvline(0,color="#999",lw=0.6,ls="--")
axC.set_yticks(range(len(oth))); axC.set_yticklabels([o[0] for o in oth],fontsize=6.0)
axC.set_xlabel("Hedges' g (IBD)"); lab(axC,"C")
save(fig,"Figure 5.png")

# ============================ F6 : sensitivity & publication bias ============================
es=[r for r in P["CRC"]["rows"] if r.get("g") is not None]
def _dl6(y,v):
    w=1/v; Q=float((w*(y-(w*y).sum()/w.sum())**2).sum()); C=w.sum()-(w**2).sum()/w.sum()
    t2=max(0,(Q-(len(y)-1))/C) if C>0 else 0.0; wr=1/(v+t2)
    return float((wr*y).sum()/wr.sum())
loo=[]
for i in range(len(es)):
    keep=[e for j,e in enumerate(es) if j!=i]
    loo.append(_dl6(np.array([e["g"] for e in keep]),np.array([e["se"] for e in keep])**2))
ys=np.array([e["g"] for e in es]); ses=np.array([e["se"] for e in es]); mu=P["CRC"]["g"]
fig=plt.figure(figsize=(W,4.8))
gs=fig.add_gridspec(2,2,hspace=0.55,wspace=0.30,left=0.13,right=0.975,top=0.92,bottom=0.11)
ax=fig.add_subplot(gs[0,0]); ax.scatter(ys,ses,color="#2c5f8a",s=14,label="study")
ax.axvline(mu,color="#c0392b",lw=0.9,ls="--",label="pooled g = %.2f"%mu)
ax.set_xlabel("Hedges' g"); ax.set_ylabel("SE"); ax.invert_yaxis(); ax.legend(frameon=False,fontsize=6.5,loc="upper right"); lab(ax,"A")
ax=fig.add_subplot(gs[0,1]); ax.scatter(ys,ses,color="#2c5f8a",s=14)
ax.axvline(mu,color="#c0392b",lw=0.9,label="observed")
tf=P["CRC"]["trimfill"]; ax.axvline(tf["adj_g"],color="#1f4e79",lw=0.9,ls="--",label="trim-fill (k$_0$=%d)"%tf["k0"])
ax.set_xlabel("Hedges' g"); ax.set_ylabel("SE"); ax.invert_yaxis(); ax.legend(frameon=False,fontsize=6.5,loc="upper right"); lab(ax,"B")
ax=fig.add_subplot(gs[1,0]); ax.scatter(loo,range(len(loo)),color="#2c5f8a",s=11)
ax.axvline(mu,color="#c0392b",lw=0.9,ls="--"); ax.set_yticks([])
ax.set_xlabel("pooled CRC g (leave-one-out)"); ax.set_ylabel("studies")
ax.text(0.02,0.95,"range %.3f\u2013%.3f"%(min(loo),max(loo)),transform=ax.transAxes,va="top",fontsize=6.5)
lab(ax,"C")
ax=fig.add_subplot(gs[1,1]); pcs=["1e-6","1e-2"]; crc=[0.312,0.302]; ibd=[-0.396,-0.360]
ax.plot([0,1],crc,"o-",color="#2c5f8a",lw=1.0,ms=3.8,label="CRC")
ax.plot([0,1],ibd,"o-",color="#c0392b",lw=1.0,ms=3.8,label="IBD")
ax.axhline(0,color="#999",lw=0.5,ls=":"); ax.set_xticks([0,1]); ax.set_xticklabels(pcs)
ax.set_xlabel("pseudocount"); ax.set_ylabel("pooled Hedges' g"); ax.legend(frameon=False,fontsize=6.5,loc="center right"); lab(ax,"D")
save(fig,"Figure 6.png")

# ============================ S1 : PRISMA ============================
fig=plt.figure(figsize=(W,5.5))
ax=fig.add_axes([0.03,0.01,0.94,0.92]); ax.set_xlim(0,16); ax.set_ylim(0,23); ax.axis("off")
ax.add_patch(Rectangle((0,0),16,23,facecolor="#f5f9fd",edgecolor="#bcd0e6",lw=0.9,zorder=-10))
def box(x,y,w,h,txt,fc="#eef4fb",ec="#2c5f8a"):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle="round,pad=0.05,rounding_size=0.14",fc=fc,ec=ec,lw=0.7))
    ax.text(x+w/2,y+h/2,txt,ha="center",va="center",fontsize=FS)
def side(x,y,w,h,txt):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle="round,pad=0.05,rounding_size=0.14",fc="#f5f5f5",ec="#9a9a9a",lw=0.6))
    ax.text(x+w/2,y+h/2,txt,ha="center",va="center",fontsize=FS,color="#444")
def arr(y0,y1): ax.add_patch(FancyArrowPatch((5.1,y0),(5.1,y1),arrowstyle="-|>",mutation_scale=7,lw=0.8,color="#2c5f8a"))
def conn(y): ax.add_patch(FancyArrowPatch((8.2,y),(9.2,y),arrowstyle="-|>",mutation_scale=9,lw=0.8,color="#9a9a9a"))
box(0.4,20.6,7.8,1.6,"Records identified (n = 242)"); side(9.2,20.6,6.4,1.6,"Duplicates removed\n(n = 59)"); conn(21.4); arr(20.6,19.4)
box(0.4,17.8,7.8,1.6,"Records after de-duplication\n(n = 183)"); arr(17.8,16.6)
box(0.4,15.0,7.8,1.6,"Records screened (n = 183)")
side(9.2,14.6,6.4,1.6,"Additional records from\nexpanded search (n = 419)"); conn(15.8)
ax.add_patch(FancyArrowPatch((12.4,15.4),(8.2,15.4),arrowstyle="-|>",mutation_scale=9,lw=0.8,color="#9a9a9a"))
box(0.4,12.2,7.8,1.6,"Expanded corpus assessed\n(n = 602)")
side(9.2,11.0,6.4,3.0,"Excluded (n = 451)\nnon-human 102; no archaea 163\nother 186: reviews 165,\nanimal/rumen 13, no control 6,\nin vitro 2"); conn(13.0); arr(12.2,11.0)
box(0.4,9.4,7.8,1.6,"Reports sought (n = 151)"); side(9.2,9.4,6.4,1.6,"Not retrieved\n(n = 1)"); conn(10.2); arr(9.4,8.2)
box(0.4,6.6,7.8,1.6,"Full-text assessed (n = 155)"); side(9.2,6.6,6.4,1.2,"Reference lists\n(n = 5)"); side(9.2,5.2,6.4,1.0,"Irrelevant (n = 4)"); conn(7.4); conn(5.7); arr(6.6,4.6)
box(0.4,3.8,7.8,1.6,"Qualitative synthesis\n(n = 151)"); arr(3.8,2.6)
box(0.4,1.0,7.8,1.6,"Quantitative synthesis\n(n = 83 studies; 21,400 samples)")
ax.text(0.2,22.7,"Supplementary Figure S1",fontweight="bold",color="#1f4e79",fontsize=FS)
save(fig,"Figure S1.png")

# ============================ S2 : MR power ============================
fig=plt.figure(figsize=(W,2.6))
ax=fig.add_axes([0.12,0.20,0.84,0.70])
ORS=np.linspace(1.0,1.4,80); z=1.959964; se=math.log(1.14)/(z+0.8416)
pw=[1-stats.norm.cdf(z-math.log(o)/se)+stats.norm.cdf(-z-math.log(o)/se) for o in ORS]
ax.plot(ORS,[p*100 for p in pw],color="#2c5f8a",lw=1.3)
ax.axhline(80,color="#888",lw=0.7,ls="--",label="80% power")
ax.axvline(1.06,color="#c0392b",lw=1.0,label="observed OR (1.06)")
ax.axvline(1.14,color="#888",lw=0.7,ls=":",label="minimum detectable OR (1.14)")
ax.set_xlabel("true OR (per 1-SD exposure)"); ax.set_ylabel("statistical power (%)"); ax.set_ylim(0,100)
ax.legend(frameon=False,fontsize=6.5,loc="lower right")
ax.set_title("Supplementary Figure S3",loc="left",fontweight="bold",color="#1f4e79")
save(fig,"Figure S3.png")
# ============================ S3 : 16S arm ============================
fig=plt.figure(figsize=(W,3.9))
gs=fig.add_gridspec(1,3,width_ratios=[1.0,0.95,1.25],wspace=0.42,left=0.10,right=0.975,top=0.86,bottom=0.13)
rows16=[]
for r in csv.DictReader(open("16s_full_results.tsv"),delimiter="\t"):
    if r["status"]!="OK": continue
    rows16.append({"grp":r["grp"],"proj":r["proj"],"tot":int(r["tot"]),"arc":int(r["arc_tot"]),"frac":float(r["arcfrac"])})
def sel(p_,g_): return [x for x in rows16 if x["proj"]==p_ and x["grp"]==g_]
axB=fig.add_subplot(gs[0,0])
groups=[("PRJEB53891","Control"),("PRJEB53891","CRC"),("PRJNA763023","Control"),("PRJNA763023","CRC")]; xs=[0,0.7,1.9,2.6]
for xx,(p_,g_) in zip(xs,groups):
    vals=[math.log10(v["frac"]+1e-6) for v in sel(p_,g_)]
    bp=axB.boxplot([vals],positions=[xx],widths=0.5,showfliers=False,patch_artist=True,medianprops=dict(color="k",lw=0.8))
    bp["boxes"][0].set(facecolor=("#9ecae1" if g_=="Control" else "#fc9272"),edgecolor="k",lw=0.5)
    jit=(np.random.RandomState(0).rand(len(vals))-0.5)*0.2
    axB.scatter(np.full(len(vals),xx)+jit,vals,s=2.2,c=("#4292c6" if g_=="Control" else "#de2d26"),alpha=0.45,linewidths=0)
axB.set_xticks(xs); axB.set_xticklabels(["Ctrl","CRC","Ctrl","CRC"],fontsize=6.5)
axB.set_ylabel("log$_{10}$ archaeal fraction"); lab(axB,"A")
axC=fig.add_subplot(gs[0,1])
xr=[x for x in rows16 if x["proj"]=="PRJNA763023"]; xr.sort(key=lambda x:x["tot"]); n=len(xr); terc=[];prev=[]
for i in range(3):
    seg=xr[i*n//3:(i+1)*n//3]; terc.append(seg[len(seg)//2]["tot"]); prev.append(sum(1 for x in seg if x["arc"]>0)/len(seg)*100)
axC.plot(range(3),prev,"o-",color="#2c5f8a",lw=1.0,ms=3.8)
axC.set_xticks(range(3)); axC.set_xticklabels(["%.0fk"%(t/1000) for t in terc])
axC.set_xlabel("depth (median reads)"); axC.set_ylabel("detection (%)"); axC.set_ylim(0,max(prev)*1.5)
for i,v in enumerate(prev): axC.text(i,v+max(prev)*0.12,"%.1f"%v,ha="center",fontsize=6.5)
lab(axC,"B")
axD=fig.add_subplot(gs[0,2])
items2=[("P1 deep",0.735,0.400),("P2 shallow",-0.055,0.062),("Pooled",0.241,0.382)]
y=0;yt=[];yl=[]
for n_,g_,se_ in items2:
    pooled=n_.startswith("Pooled")
    axD.plot([g_-1.96*se_,g_+1.96*se_],[y,y],color=("#000" if pooled else "#2c5f8a"),lw=(1.0 if pooled else 0.7))
    axD.plot(g_,y,("D" if pooled else "o"),color=("#c0392b" if pooled else "#2c5f8a"),ms=(4 if pooled else 3))
    yt.append(y); yl.append(n_); y-=1
axD.axvline(0,color="#999",lw=0.6,ls="--"); axD.set_yticks(yt); axD.set_yticklabels(yl,fontsize=6.5)
for t,l in zip(axD.get_yticklabels(),yl):
    if l.startswith("Pooled"): t.set_fontweight("bold")
axD.set_xlabel("Hedges' g"); lab(axD,"C")
ax.text(0.5,0.99,"Supplementary Figure S2",transform=fig.transFigure,ha="center",va="top",fontweight="bold",color="#1f4e79")
save(fig,"Figure S2.png")
print("DONE v3")
