#!/bin/bash
# Run the raw-read line for one project.
# Usage: run_all.sh <project> <manifest.tsv>
set -euo pipefail
source "$(dirname "$0")/../config.sh"
PROJ="$1"; MANIFEST="$2"
case "$PROJ" in
  16S*) bash "$(dirname "$0")/map16s.sh" "$MANIFEST" "$PROJ" "$OUT_DIR/${PROJ}_16s.tsv" ;;
  *)    bash "$(dirname "$0")/downsample.sh" "$MANIFEST" "$OUT_DIR/${PROJ}_downsample.tsv"
        bash "$(dirname "$0")/mapq_bins.sh" "$MANIFEST" "$OUT_DIR/${PROJ}_mapq.tsv" ;;
esac
