#!/bin/bash
# Downsampling experiment: 25k, 50k, 100k, 250k, 500k reads; five replicates.
# Usage: downsample.sh <manifest.tsv> <output.tsv>
# Manifest: study <TAB> group <TAB> run <TAB> url
set -euo pipefail
source "$(dirname "$0")/../config.sh"
MANIFEST="$1"; OUT="$2"
printf "study\tgrp\trun\tdepth_rep\ttot\tarch\n" > "$OUT"
while IFS=$'\t' read -r study grp run url; do
  [ -z "${run:-}" ] && continue
  fq="$DATA_DIR/${run}.fastq.gz"
  [ -s "$fq" ] || { echo "missing $fq"; continue; }
  pool=$(mktemp); zcat "$fq" | head -8000000 > "$pool"
  for D in 25 50 100 250 500; do
    for R in 1 2 3 4 5; do
      sub=$(mktemp); n=$((D*1000))
      python3 - "$pool" "$sub" "$n" "$run" "$D" "$R" <<'PY'
import sys, random, hashlib
pool, out, n, run, depth, rep = sys.argv[1], sys.argv[2], int(sys.argv[3]), sys.argv[4], sys.argv[5], sys.argv[6]
recs=[]; f=open(pool)
while True:
    h=f.readline(); s=f.readline(); p=f.readline(); q=f.readline()
    if not q: break
    recs.append(h+s+p+q)
seed=int(hashlib.md5(f"{run}|{depth}|{rep}".encode()).hexdigest()[:8],16)
random.seed(seed)
idx=sorted(random.sample(range(len(recs)), min(n,len(recs))))
open(out,"w").writelines(recs[i] for i in idx)
PY
      tot=$(( $(wc -l < "$sub") / 4 ))
      arch=$(bowtie2 -x "$REF_DIR/arch_idx" -U "$sub" -p 1 --no-unal 2>/dev/null | samtools view -F 4 -c -)
      printf "%s\t%s\t%s\t%s_%s\t%d\t%d\n" "$study" "$grp" "$run" "$D" "$R" "$tot" "$arch" >> "$OUT"
      rm -f "$sub"
    done
  done
  rm -f "$pool"
done < "$MANIFEST"
