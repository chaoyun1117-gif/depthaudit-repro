#!/bin/bash
# Count archaeal reads in one FASTQ file.
# Usage: align_count.sh <sample.fastq.gz> [index]
set -euo pipefail
source "$(dirname "$0")/../config.sh"
FQ="$1"; IDX="${2:-$REF_DIR/arch_idx}"
bowtie2 -x "$IDX" -U "$FQ" -p "$THREADS" --no-unal 2>/dev/null \
  | samtools view -F 4 -c -
