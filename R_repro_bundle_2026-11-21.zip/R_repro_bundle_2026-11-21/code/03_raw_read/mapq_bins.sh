#!/bin/bash
# Mapping-quality distribution per sample (first 2M reads).
# Usage: mapq_bins.sh <manifest.tsv> <output.tsv>
set -euo pipefail
source "$(dirname "$0")/../config.sh"
MANIFEST="$1"; OUT="$2"
printf "grp\trun\ttot\tn\tmq0\tlt10\t10to20\tge20\n" > "$OUT"
while IFS=$'\t' read -r grp run url; do
  [ -z "${run:-}" ] && continue
  fq="$DATA_DIR/${run}.fastq.gz"; [ -s "$fq" ] || continue
  tmp=$(mktemp); zcat "$fq" | head -2000000 > "$tmp"
  tot=$(( $(wc -l < "$tmp") / 4 ))
  bowtie2 -x "$REF_DIR/arch_idx" -U "$tmp" --no-unal -p "$THREADS" 2>/dev/null \
    | samtools view -F 4 - 2>/dev/null \
    | awk -v tot="$tot" -v run="$run" -v grp="$grp" '{mq=$5;n++; if(mq==0)z++; else if(mq<10)l++; else if(mq<20)m++; else h++} END{printf "%s\t%s\t%d\t%d\t%d\t%d\t%d\t%d\n",grp,run,tot,n,z,l,m,h}' >> "$OUT"
  rm -f "$tmp"
done < "$MANIFEST"
