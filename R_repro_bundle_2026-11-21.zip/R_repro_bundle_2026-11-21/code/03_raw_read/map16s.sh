#!/bin/bash
# 16S amplicon line: domain-level counts and archaeal fraction.
# Usage: map16s.sh <manifest.tsv> <project> <output.tsv>
set -euo pipefail
source "$(dirname "$0")/../config.sh"
MANIFEST="$1"; PROJ="$2"; OUT="$3"
printf "grp\trun\tproj\ttot\tarch\tmeth\tarc_tot\tarcfrac\tstatus\n" > "$OUT"
while IFS=$'\t' read -r grp run url extra; do
  [ -z "${run:-}" ] && continue
  fq="$DATA_DIR/${run}.fastq.gz"; [ -s "$fq" ] || { printf "%s\t%s\t%s\tFAIL\t0\t0\t0\tNA\tNA\n" "$grp" "$run" "$PROJ" >> "$OUT"; continue; }
  tot=$(( $(wc -l < "$fq") / 4 ))
  read -r arc meth < <(bowtie2 -x "$REF_DIR/16s_dom_idx" -U "$fq" --local -p "$THREADS" --no-unal 2>/dev/null \
    | samtools view -F 4 - 2>/dev/null \
    | awk '{split($3,a,"|"); if(a[1]=="METH")m++; else if(a[1]=="ARCH")r++} END{print r+0, m+0}')
  awk -v a="$arc" -v m="$meth" -v t="$tot" -v g="$grp" -v r="$run" -v p="$PROJ" 'BEGIN{printf "%s\t%s\t%s\t%d\t%d\t%d\t%d\t%.8f\tOK\n",g,r,p,t,a,m,a+m,(t>0)?(a+m)/t:0}' >> "$OUT"
done < "$MANIFEST"
