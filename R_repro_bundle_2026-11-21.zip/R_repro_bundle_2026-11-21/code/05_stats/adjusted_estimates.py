# Per-study covariate-adjusted standardised effect (method C)
import pandas as pd, numpy as np, warnings, statsmodels.formula.api as smf, json
import os
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

warnings.filterwarnings("ignore")
d=pd.read_csv("dedup_analysis.csv",low_memory=False)
d["y"]=pd.to_numeric(d.archaea_rel,errors="coerce").fillna(0); d["st"]=d.st.astype(str)
d["lg"]=np.log10(d.nr.where(d.nr>0)); d["lgpos"]=np.log10(d.y+1e-6)
if "nb" in d.columns:
    d=d.drop(columns=["nb"])
m=pd.read_csv("sampleMetadata.csv",low_memory=False).drop_duplicates("sample_id")
m["nb"]=pd.to_numeric(m["number_bases"],errors="coerce")
d=d.merge(m[["sample_id","nb"]].rename(columns={"sample_id":"sample"}),on="sample",how="left")
d["lb"]=np.log10(d.nb.where(d.nb>0))
def dl(gs,vs):
    gs=np.array(gs);vs=np.array(vs);w=1/vs
    Q=float((w*(gs-(w*gs).sum()/w.sum())**2).sum()); C=w.sum()-(w**2).sum()/w.sum()
    t2=max(0,(Q-(len(gs)-1))/C) if C>0 else 0; wr=1/(vs+t2)
    mu=float((wr*gs).sum()/wr.sum()); se=float(np.sqrt(1/wr.sum()))
    return dict(k=len(gs),g=round(mu,4),lo=round(mu-1.96*se,4),hi=round(mu+1.96*se,4),I2=round(max(0,(Q-(len(gs)-1))/Q*100),1))
def adj(cov):
    out={}
    dd=d.dropna(subset=[cov])
    for lab in ["CRC","IBD"]:
        s=dd[dd.disease.isin([lab,"healthy"])]; gs=[];vs=[]
        for st,g in s.groupby("st"):
            c=g[g.disease==lab]; k=g[g.disease=="healthy"]
            if len(c)<5 or len(k)<5: continue
            gg=pd.concat([c,k]).copy(); gg["case"]=[1]*len(c)+[0]*len(k)
            fit=smf.ols("lgpos ~ case + %s"%cov,gg).fit(); sd=gg.lgpos.std(ddof=1)
            gs.append(fit.params["case"]/sd); vs.append((fit.bse["case"]/sd)**2)
        out[lab]=dl(gs,vs)
    return out
res={"depth_reads":adj("lg"),"yield_bases":adj("lb")}
json.dump(res,open("adjusted_estimates.json","w"),indent=1)
print(json.dumps(res,indent=1))
