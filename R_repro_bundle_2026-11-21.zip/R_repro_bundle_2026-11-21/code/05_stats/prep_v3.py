import pandas as pd, numpy as np, json, math
d=pd.read_csv("dedup_analysis.csv",low_memory=False)
d["y"]=pd.to_numeric(d.archaea_rel,errors="coerce").fillna(0); d["st"]=d.st.astype(str)
def h(a,b):
    n1,n2=len(a),len(b)
    if n1<5 or n2<5: return np.nan,np.nan
    s1,s2=a.std(ddof=1),b.std(ddof=1); sp=math.sqrt(((n1-1)*s1**2+(n2-1)*s2**2)/(n1+n2-2))
    if not np.isfinite(sp) or sp==0: return np.nan,np.nan
    g=(a.mean()-b.mean())/sp*(1-3/(4*(n1+n2)-9)); return g,math.sqrt((n1+n2)/(n1*n2)+g*g/(2*(n1+n2)))
def dl(gs,vs):
    gs=np.array(gs,float);vs=np.array(vs,float);ok=(~np.isnan(gs))&(~np.isnan(vs));gs,vs=gs[ok],vs[ok]
    if not len(gs): return None
    w=1/vs;Q=float((w*(gs-(w*gs).sum()/w.sum())**2).sum());C=w.sum()-(w**2).sum()/w.sum()
    t2=max(0,(Q-(len(gs)-1))/C) if C>0 else 0;wr=1/(vs+t2)
    mu=float((wr*gs).sum()/wr.sum());se=float(np.sqrt(1/wr.sum()))
    return dict(k=int(len(gs)),g=round(mu,4),se=round(se,4),lo=round(mu-1.96*se,4),hi=round(mu+1.96*se,4),
        I2=round(max(0,(Q-(len(gs)-1))/Q*100),1) if Q>0 else 0.0,tau2=round(float(t2),4))
def trimfill(gs,vs):
    gs=np.array(gs,float);vs=np.array(vs,float);ok=(~np.isnan(gs))&(~np.isnan(vs));gs,vs=gs[ok],vs[ok]
    base=dl(gs,vs); mu=base["g"]; k0=0
    for _ in range(50):
        # sort by |g-mu| to estimate the number of missing studies
        dev=np.abs(gs-mu); order=np.argsort(dev)[::-1]
        r=len(gs); L0=0
        for kk in range(1,len(gs)):
            side=np.sign(gs[order[:kk]]-mu); L0=max(L0, int(abs(side.sum())))
        if L0==k0: break
        k0=L0
        worst=order[:k0]
        gs2=np.concatenate([gs, 2*mu-gs[worst]]); vs2=np.concatenate([vs, vs[worst]])
        mu=dl(gs2,vs2)["g"]
    return dict(adj_g=round(float(mu),4),k0=int(k0),orig=base)
out={}
d["ph"]=d.disease.replace({"healthy":"healthy"})
for ph in ["CRC","IBD","Adenoma","T2D","IGT","Hypertension","ACVD","MS"]:
    lab={"Adenoma":"adenoma"}.get(ph,ph)
    sub=d[d.disease.isin([lab,"healthy"])] if lab!=ph else d[d.disease.isin([ph,"healthy"])]
    if lab==ph and ph=="Adenoma": sub=d[d.disease.isin(["adenoma","healthy"])]
    rows=[];gs=[];vs=[]
    for st,g in sub.groupby("st"):
        c=g[g.disease==lab];k=g[g.disease=="healthy"]
        if len(c)<5 or len(k)<5: continue
        a,s=h(np.log10(c.y+1e-6).values,np.log10(k.y+1e-6).values)
        rows.append(dict(study=st,n_case=len(c),n_ctrl=len(k),g=None if np.isnan(a) else round(a,4),se=None if np.isnan(s) else round(s,4)))
        gs.append(a);vs.append(s*s)
    p=dl(gs,vs)
    out[ph]=dict(rows=rows,**(p or {}),n_studies=len(rows))
    if ph=="CRC": out[ph]["trimfill"]=trimfill(gs,vs)
json.dump(out,open("pool_v3.json","w"),indent=1)
for k,v in out.items(): print(k,"k=",v.get("k"),"g=",v.get("g"),"I2=",v.get("I2"),"trimfill=",v.get("trimfill",{}).get("adj_g"),"k0=",v.get("trimfill",{}).get("k0"))
