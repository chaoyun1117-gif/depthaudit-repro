# Supplementary Code S1 — full reproducible workflow

Reproduction package for: *Sequencing-depth-dependent detection limits of gut methanogenic archaea and detection-driven distortion of microbiome–disease associations: a depth-aware re-appraisal of 21,400 metagenomes*.

This package runs from raw public reads to every figure and table in the manuscript.

---

## 0. Requirements

| Item | Requirement |
| --- | --- |
| Disk | ~120 GB (FASTQ for all projects) |
| CPU | 4 cores recommended |
| Tools | `bowtie2` ≥2.5, `samtools` ≥1.17, `wget`, `gzip`, `efetch` (entrez-direct) |
| Python | 3.12; `pip install -r requirements.txt` |
| R | ≥4.3 with `curatedMetagenomicData` and `ExperimentHub` (only for the cMD exports) |

Set paths once:
```bash
source config.sh
# optional: export DATA_DIR=/path/to/fastq REF_DIR=/path/to/refs THREADS=4
```

---

## 1. Download raw reads (~100 GB, several hours)

```bash
bash 00_download/download_reads.sh 00_download/manifests/PRJEB10878_China_CRC.tsv
bash 00_download/download_reads.sh 00_download/manifests/PRJDB4176_Japan_CRC.tsv
bash 00_download/download_reads.sh 00_download/manifests/PRJNA385949_Hall_IBD.tsv
bash 00_download/download_reads.sh 00_download/manifests/PRJEB1220_MetaHIT_IBD.tsv
bash 00_download/download_reads.sh 00_download/manifests/PRJNA398089_HMP2_IBD.tsv
bash 00_download/download_reads.sh 00_download/manifests/PRJNA422434_China_T2D.tsv
bash 00_download/download_reads.sh 00_download/manifests/PRJDB11845_Japan_CRC_16S.tsv
bash 00_download/download_reads.sh 00_download/manifests/PRJDB16834_Japan_Adenoma_16S.tsv
bash 00_download/download_reads.sh 00_download/manifests/Vogtmann_IBD.tsv
bash 00_download/download_reads.sh 00_download/manifests/16S_multi_project.tsv
```
Files are written to `$DATA_DIR/<run>.fastq.gz`; existing valid files are skipped.

---

## 2. Build reference indices (~10 min)

```bash
bash 01_reference/build_arch_index.sh   # 135 contigs: M. smithii (1), M. stadtmanae (108), M. luminyensis (26)
bash 01_reference/build_16s_index.sh    # RefSeq Targeted Loci 16S, dual-domain tags
```
Outputs: `$REF_DIR/arch_idx`, `$REF_DIR/16s_dom_idx`, `$REF_DIR/16s_arc_idx`.

The 16S counts in the manuscript (26,876 bacterial + 1,160 archaeal) correspond to the RefSeq release used at the time; counts drift between releases. Record the download date.

---

## 3. Quality control

**No adapter trimming or base-quality filtering was applied** (see `02_qc/README.md`). Reads were used as deposited; unaligned reads were removed with `samtools view -F 4`. An optional `fastp` command is given for sensitivity testing only.

---

## 4. Raw-read line (downsampling, MAPQ, 16S)

```bash
bash 03_raw_read/run_all.sh PRJEB10878 00_download/manifests/PRJEB10878_China_CRC.tsv
bash 03_raw_read/run_all.sh PRJDB4176  00_download/manifests/PRJDB4176_Japan_CRC.tsv
bash 03_raw_read/run_all.sh 16S        00_download/manifests/16S_multi_project.tsv
```
Per-project outputs in `$OUT_DIR`:
- `<project>_downsample.tsv` — per-sample, per-depth archaeal read counts (Tables 10; Figure 3B,C)
- `<project>_mapq.tsv` — MAPQ bins (Figure 2A,B; Supplementary Table S2C)
- `<project>_16s.tsv` — domain counts and archaeal fraction (Table 11; Supplementary Figure S2)

Downsampling uses fixed seeds derived from `md5(run|depth|replicate)`, so replicates are reproducible.

---

## 5. Quantitative line (curatedMetagenomicData)

```bash
Rscript 00_download/fetch_cmd.R
```
This exports `sampleMetadata.csv` and the long-format abundance table. `04_cmd/prepare_data.py` merges them into `dedup_analysis.csv` (21,400 unique samples; 83 studies; two snapshots de-duplicated).

> Public cMD snapshots change over time. The manuscript used the 2021-03-31 and 2021-10-14 snapshots. If your installation returns different counts, pin the ExperimentHub snapshot or use the archived exports.

---

## 6. Statistical analysis (~1 min)

```bash
python3 04_cmd/prepare_data.py        # -> dedup_analysis.csv
python3 04_cmd/analysis_final.py      # -> final_numbers.json (N, detection model, LOO, two-part)
python3 05_stats/prep_v3.py           # -> pool_v3.json (per-phenotype g, DL, trim-and-fill)
python3 05_stats/adjusted_estimates.py# -> adjusted_estimates.json (method C: depth and yield)
```
Expected values:
- N = 21,400; 83 studies; detection 26.12%; depth OR 2.963 per log10; pseudo-R² 0.194
- CRC g = +0.312 (+0.136 to +0.488); IBD g = −0.396 (−0.672 to −0.120)
- Method C: depth CRC +0.3436 / IBD −0.4068; yield CRC +0.3385 / IBD −0.4051

---

## 7. Figures and tables (~10 s)

```bash
python3 06_figures/make_composites_v4.py   # Figures 1–6, Supplementary Figures S1–S3
python3 06_figures/build_supp_xlsx.py      # Supplementary Tables S2–S3 (XLSX)
```

---

## Mapping of outputs to the manuscript

| Output | Manuscript item |
| --- | --- |
| `outputs/final_numbers.json` | Abstract, §3.2, §3.4, Tables 2 and 4 |
| `outputs/pool_v3.json` | Tables 4–7, Figure 4 |
| `outputs/adjusted_estimates.json` | Tables 8 and 12 |
| `*_downsample.tsv` | Figure 3B,C; Supplementary Table S2F |
| `*_mapq.tsv` | Figure 2A,B; Supplementary Table S2C |
| `*_16s.tsv` | Table 11; Supplementary Figure S2 |
| `dedup_analysis.csv` | all sample-level analyses |

## Notes
- The raw-read line re-quantifies archaea from primary reads; the small derived tables are also provided in `inputs/` so the statistical and figure steps can be run without re-downloading FASTQ.
- PRJEB12449 yielded ~0 archaeal reads and was excluded from pooling.
- The 3/depth adequacy benchmark is analytical (Poisson, one-read rule) and threshold-specific; see Supplementary Note S1 (DARE).
