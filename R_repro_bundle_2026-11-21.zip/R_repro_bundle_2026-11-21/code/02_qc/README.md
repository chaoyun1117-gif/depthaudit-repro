# Quality control

**No adapter trimming or base-quality filtering was applied.** Reads were used
as deposited in ENA/SRA, and quality was handled at the alignment/count stage
(bowtie2 end-to-end for WGS; `--local` for 16S; reads with no valid alignment
excluded with `samtools view -F 4`).

This is deliberate: the study asks what a standard public-data workflow would
detect, so pre-trimming would change the very quantity being measured. If you
wish to test QC sensitivity, the following optional command can be applied
before alignment:

```bash
fastp -i sample.fastq.gz -o sample.qc.fastq.gz -q 20 -u 30 -l 50 --thread 4
```

Re-running the pipeline with `*.qc.fastq.gz` replaces the input path in
`03_raw_read/*.sh`; the manuscript's numbers were produced without this step.
