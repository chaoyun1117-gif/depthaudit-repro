#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

# Keep memory below 75% of physical RAM and force single-threaded BLAS.
TOTAL_KB="$(awk '/MemTotal/ {print $2}' /proc/meminfo)"
MAX_KB="$(( TOTAL_KB * 75 / 100 ))"
ulimit -v "$MAX_KB" || true
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export MKL_NUM_THREADS=1
export NUMEXPR_NUM_THREADS=1

mkdir -p results figures
if [[ ! -d code/04_cmd ]]; then
  echo "code/ is missing. Re-create it from Additional_file_3.zip." >&2
  exit 1
fi
if [[ ! -d depthaudit/depthaudit ]]; then
  echo "depthaudit/ is missing." >&2
  exit 1
fi

echo "[1/4] R export: curatedMetagenomicData -> EH_archaea_merged.csv"
(
  cd data
  Rscript ../scripts/fetch_cmd.R
  Rscript ../scripts/export_cmd.R EH_archaea_merged.csv sampleMetadata.csv
)

echo "[2/4] DepthAudit: depth model + two-part model"
PYTHONPATH="$ROOT/depthaudit" python3 -m depthaudit audit \
  --input "$ROOT/data/EH_archaea_merged.csv" \
  --out "$ROOT/results" \
  --quiet

echo "[3/4] Original statistics and figures"
cp "$ROOT/data/dedup_analysis.csv" "$ROOT/code/dedup_analysis.csv"
cp "$ROOT/data/EH_archaea_merged.csv" "$ROOT/code/EH_archaea_merged.csv"
cp "$ROOT/data/sampleMetadata.csv" "$ROOT/code/sampleMetadata.csv"
cp "$ROOT/code/outputs/"*.json "$ROOT/code/"

(
  cd code
  python3 04_cmd/analysis_final.py
  python3 05_stats/prep_v3.py
  python3 05_stats/adjusted_estimates.py
  python3 06_figures/make_composites_v4.py
  python3 06_figures/build_supp_xlsx.py
)

echo "[4/4] Copy generated figures"
if [[ -d code/figures ]]; then
  mkdir -p figures/generated
  cp -a code/figures/. figures/generated/
fi

echo "DONE"
echo "Results:  $ROOT/results"
echo "Figures:  $ROOT/figures/generated"
